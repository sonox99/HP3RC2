"""Controlled project tools for AgentHub v5.

This module intentionally exposes operations instead of a general shell.  Every
operation checks the two configured project roots, the selected mode, timeout,
and writes a complete JSONL audit record.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
import hashlib
from datetime import datetime
from pathlib import Path
from typing import Any

from project_index import (AGENTHUB_ROOT, allowed_roots, file_metadata,
                           list_directory, project_root, read_project_file,
                           resolve_task_path, task_workdir)

MODES = {"analysis", "autonomous", "controlled"}
MODE_LABELS = {"analysis": "Analyse", "autonomous": "Autonom", "controlled": "Kontrolliert"}
# No generic shell is exposed. Build tools may execute project-defined build scripts,
# so they are only available in Controlled/Autonomous mode.
MUTATING_TOOLS = {"write_file", "python", "cmake", "ninja", "msbuild", "compiler"}
SAFE_TOOLS = {"python", "git", "cmake", "ninja", "msbuild", "compiler"}
READ_ONLY_GIT_COMMANDS = {"status", "diff", "log", "show", "branch", "rev-parse", "ls-files"}
DENIED_ARGUMENTS = {"remove-item", "del", "erase", "format", "shutdown", "restart-computer", "reg.exe", "diskpart"}
LOG_PATH = AGENTHUB_ROOT / "logs" / "executor.jsonl"
_active: dict[str, subprocess.Popen] = {}
_active_lock = threading.Lock()


def _inside(path: Path, roots: list[Path] | None = None) -> bool:
    # Never accept a caller-supplied root outside the immutable AgentHub boundary.
    boundary = AGENTHUB_ROOT.resolve()
    permitted = [boundary, *[Path(root).resolve() for root in allowed_roots()]]
    target = path.resolve()
    return any(target == root or root in target.parents for root in permitted)


def _record(event: dict[str, Any]) -> None:
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    event = {"time": datetime.now().isoformat(timespec="seconds"), **event}
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")


def _result(tool: str, status: str, started: float, **extra: Any) -> dict[str, Any]:
    output = {"tool": tool, "status": status, "duration_s": round(time.perf_counter() - started, 3), **extra}
    _record(output)
    return output


def validate_mode(mode: str) -> str:
    mode = (mode or "analysis").lower().strip()
    if mode not in MODES:
        raise ValueError(f"Unbekannter Berechtigungsmodus: {mode}")
    return mode


def git_snapshot(cwd: str | Path) -> dict[str, Any]:
    started = time.perf_counter()
    directory = Path(cwd).resolve()
    if not _inside(directory):
        return _result("git", "access_denied", started, message="Arbeitsordner liegt ausserhalb der freigegebenen Roots.")
    if not (directory / ".git").exists():
        return _result("git", "not_available", started, exit_code=None, stdout="", stderr="Kein Git-Repository im Arbeitsordner.")
    try:
        proc = subprocess.run(["git", "status", "--short", "--branch"], cwd=directory, capture_output=True,
                              text=True, timeout=30, shell=False)
        return _result("git", "completed", started, exit_code=proc.returncode, stdout=proc.stdout, stderr=proc.stderr)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return _result("git", "error", started, exit_code=None, stdout="", stderr=str(exc))


def read_file(path: str, base_dir: str | Path | None = None) -> dict[str, Any]:
    return read_project_file(path, base_dir=base_dir)


def search_files(query: str, limit: int = 20) -> dict[str, Any]:
    from project_index import search_project
    started = time.perf_counter()
    hits = search_project(query, limit=limit)
    return _result("search", "completed", started, query=query, hits=hits)


def list_dir(path: str = ".", base_dir: str | Path | None = None) -> dict[str, Any]:
    return list_directory(path, base_dir=base_dir)


def write_file(path: str, content: str, mode: str, base_dir: str | Path | None = None, *, approved: bool = False) -> dict[str, Any]:
    """Write atomically, keep a unique backup, and verify the exact bytes on disk."""
    started = time.perf_counter()
    mode = validate_mode(mode)
    if not isinstance(content, str):
        return _result("write_file", "error", started, message="Dateiinhalt muss Text sein.")
    try:
        resolved, roots = resolve_task_path(path, base_dir)
    except ValueError as exc:
        return _result("write_file", "error", started, message=str(exc))
    if not _inside(resolved, roots):
        return _result("write_file", "access_denied", started, path=str(resolved),
                       message="Pfad ausserhalb der freigegebenen Roots.")
    if mode == "analysis":
        return _result("write_file", "permission_denied", started, path=str(resolved),
                       message="Analysemodus ist Read-only.")
    if mode == "controlled" and not approved:
        return _result("write_file", "approval_required", started, path=str(resolved),
                       bytes=len(content.encode("utf-8")), content_redacted=True,
                       message="Kontrollierter Modus: Änderung vorbereitet, wartet auf Freigabe.")

    payload = content.encode("utf-8")
    backup = None
    temp_path = None
    existed_before = resolved.exists()
    try:
        resolved.parent.mkdir(parents=True, exist_ok=True)
        if existed_before:
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
            backup_path = resolved.with_name(
                f"{resolved.name}.agenthub-backup-{stamp}-{uuid.uuid4().hex[:8]}"
            )
            shutil.copy2(resolved, backup_path)
            backup = str(backup_path)

        # Stage in the destination directory so os.replace is atomic on the same volume.
        fd, temp_name = tempfile.mkstemp(prefix=f".{resolved.name}.", suffix=".agenthub-tmp",
                                         dir=str(resolved.parent))
        temp_path = Path(temp_name)
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(str(temp_path), str(resolved))
        temp_path = None

        on_disk = resolved.read_bytes()
        digest = hashlib.sha256(payload).hexdigest()
        verified = on_disk == payload
        if not verified:
            if backup and Path(backup).exists():
                shutil.copy2(backup, resolved)
            elif not existed_before and resolved.exists():
                resolved.unlink()
            return _result("write_file", "verification_failed", started, path=str(resolved),
                           backup=backup, bytes=len(payload), sha256=digest, verified=False,
                           approved=bool(approved),
                           message="Nach dem Schreiben stimmen die gelesenen Bytes nicht mit dem Sollinhalt überein; Rollback wurde versucht.")

        return _result("write_file", "completed", started, path=str(resolved), backup=backup,
                       bytes=len(payload), sha256=digest, verified=True, approved=bool(approved))
    except OSError as exc:
        rollback = "not_needed"
        try:
            if backup and Path(backup).exists():
                shutil.copy2(backup, resolved)
                rollback = "restored_backup"
            elif not existed_before and resolved.exists():
                resolved.unlink()
                rollback = "removed_partial_new_file"
        except OSError as rollback_exc:
            rollback = f"rollback_failed: {rollback_exc}"
        return _result("write_file", "error", started, path=str(resolved), backup=backup,
                       rollback=rollback, message=str(exc))
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass



def _validate_tool_args(tool: str, args: list[str]) -> str | None:
    """Reject command forms that escape the intended developer-tool contract."""
    lowered = [str(arg).strip().lower() for arg in args]
    if tool == "git":
        command = next((arg for arg in lowered if not arg.startswith("-")), "")
        if command not in READ_ONLY_GIT_COMMANDS:
            return "Git ist auf read-only Unterbefehle beschraenkt; Commit/Reset/Clean/Push sind gesperrt."
        if any(arg == "--output" or arg.startswith("--output=") or arg in {
            "--git-dir", "--work-tree", "-c", "--ext-diff", "--textconv", "--exec-path"
        } for arg in lowered):
            return "Git-Option kann Dateien ausserhalb des Arbeitsbereichs beeinflussen oder externen Code starten und ist gesperrt."
        if command == "branch" and any(arg in {"-d", "--delete", "-m", "--move", "-c", "--copy", "--set-upstream-to"} for arg in lowered):
            return "Mutierende Git-Branch-Operationen sind gesperrt."
    elif tool == "python":
        # Only test/validation entry points are supported; no -c, arbitrary script,
        # pip, or module execution from the model.
        if len(lowered) < 2 or lowered[0] != "-m" or lowered[1] not in {"unittest", "pytest", "compileall"}:
            return "Python ist auf unittest/pytest/compileall beschraenkt; beliebige Skriptausfuehrung ist gesperrt."
    return None


def run_tool(tool: str, args: list[str], cwd: str | Path, mode: str, timeout: int = 300,
             job_id: str | None = None, *, approved: bool = False) -> dict[str, Any]:
    started = time.perf_counter()
    mode = validate_mode(mode)
    tool = tool.lower().strip()
    directory = Path(cwd).resolve()
    if tool not in SAFE_TOOLS:
        return _result(tool, "denied", started, exit_code=None, stdout="", stderr="Tool nicht auf der Allowlist.")
    if not _inside(directory):
        return _result(tool, "access_denied", started, exit_code=None, stdout="", stderr="WorkingDirectory ausserhalb der Roots.")
    args = [str(arg) for arg in args]
    validation_error = _validate_tool_args(tool, args)
    if validation_error:
        return _result(tool, "denied", started, exit_code=None, stdout="", stderr=validation_error)
    if any(arg.lower() in DENIED_ARGUMENTS for arg in args):
        return _result(tool, "denied", started, exit_code=None, stdout="", stderr="Gefährliches Argument blockiert.")
    if mode == "analysis" and tool in MUTATING_TOOLS:
        return _result(tool, "permission_denied", started, exit_code=None, stdout="", stderr="Analysemodus erlaubt keine Ausführung dieses Tools.")
    if mode == "controlled" and tool in MUTATING_TOOLS and not approved:
        return _result(tool, "approval_required", started, exit_code=None, stdout="", stderr="Kontrollierter Modus wartet auf Freigabe.",
                       args=args, cwd=str(directory))
    executable = shutil.which(tool)
    if tool == "python":
        executable = sys.executable
    elif tool == "compiler":
        executable = next((shutil.which(candidate) for candidate in ("cl", "clang++", "g++", "c++")
                          if shutil.which(candidate)), None)
    if not executable:
        return _result(tool, "not_available", started, exit_code=None, stdout="", stderr=f"Executable nicht gefunden: {tool}")
    command = [executable, *args]
    try:
        proc = subprocess.Popen(command, cwd=directory, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, shell=False)
        if job_id:
            with _active_lock:
                _active[job_id] = proc
        try:
            stdout, stderr = proc.communicate(timeout=max(1, min(int(timeout), 3600)))
            status = "completed" if proc.returncode == 0 else "failed"
            return _result(tool, status, started, exit_code=proc.returncode, stdout=stdout, stderr=stderr,
                           command=command, cwd=str(directory), approved=bool(approved))
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()
            return _result(tool, "timeout", started, exit_code=None, stdout=stdout, stderr=stderr,
                           command=command, cwd=str(directory), approved=bool(approved))
        finally:
            if job_id:
                with _active_lock:
                    _active.pop(job_id, None)
    except OSError as exc:
        return _result(tool, "error", started, exit_code=None, stdout="", stderr=str(exc), command=command)


def cancel(job_id: str) -> bool:
    with _active_lock:
        proc = _active.get(job_id)
    if proc and proc.poll() is None:
        proc.kill()
        _record({"event": "cancel", "job_id": job_id})
        return True
    return False


def tool_catalog() -> list[dict[str, Any]]:
    return [{"name": "read_file", "mutates": False}, {"name": "search_files", "mutates": False},
            {"name": "list_dir", "mutates": False}, {"name": "write_file", "mutates": True},
            *[{"name": name, "mutates": name in MUTATING_TOOLS} for name in sorted(SAFE_TOOLS)]]
