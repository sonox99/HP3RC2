from __future__ import annotations

import argparse
from pathlib import Path

from agenthub6.config import load_env_file
load_env_file(Path(__file__).resolve().parent / ".env")

from agenthub6.embeddings import configured_embedding_index
from project_index import DB_PATH


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the optional AgentHub 6.0 semantic vector index")
    parser.add_argument("--batch-size", type=int, default=24)
    parser.add_argument("--max-chunks", type=int)
    args = parser.parse_args()
    index = configured_embedding_index(DB_PATH, Path(__file__).resolve().parent / "data" / "agenthub-vectors-v6.sqlite3")
    if index is None:
        print("AGENTHUB_EMBEDDING_MODEL ist nicht gesetzt. Beispiel: nomic-embed-text")
        return 2
    result = index.build(batch_size=args.batch_size, max_chunks=args.max_chunks)
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
