import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mcp_bridge


FAKE_SERVER = r"""
import json, sys
TOOLS = [
    {"name": "inspect", "description": "Read-only inspection", "inputSchema": {"type": "object", "properties": {}}},
    {"name": "change", "description": "Mutating change", "inputSchema": {"type": "object", "properties": {"value": {"type": "string"}}}},
]
for line in sys.stdin:
    msg = json.loads(line)
    method = msg.get("method")
    if method == "initialize":
        result = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}},
                  "serverInfo": {"name": "test-server", "version": "1.0"}}
    elif method == "tools/list":
        result = {"tools": TOOLS}
    elif method == "tools/call":
        name = msg.get("params", {}).get("name")
        result = {"content": [{"type": "text", "text": "called:" + str(name)}], "isError": False}
    else:
        continue
    print(json.dumps({"jsonrpc": "2.0", "id": msg["id"], "result": result}), flush=True)
"""


class MCPBridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.server_script = self.root / "fake_mcp_server.py"
        self.server_script.write_text(FAKE_SERVER, encoding="utf-8")
        self.config = self.root / "mcp-servers.json"
        self.config.write_text(json.dumps({
            "servers": {
                "fixture": {
                    "enabled": True,
                    "command": sys.executable,
                    "args": ["-u", str(self.server_script)],
                    "timeout": 5,
                    "env": {},
                    "read_only_tools": ["inspect"],
                    "mutating_tools": ["change"]
                }
            }
        }), encoding="utf-8")
        self.patch = patch.object(mcp_bridge, "CONFIG_PATH", self.config)
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_discover_only_explicitly_classified_tools(self):
        catalog = mcp_bridge.discover_tools()
        self.assertEqual({(x["server"], x["name"]) for x in catalog},
                         {("fixture", "inspect"), ("fixture", "change")})
        self.assertFalse(next(x for x in catalog if x["name"] == "inspect")["mutates"])
        self.assertTrue(next(x for x in catalog if x["name"] == "change")["mutates"])

    def test_analysis_can_call_read_only_but_not_mutating(self):
        read = mcp_bridge.execute_tool("fixture", "inspect", {}, "analysis")
        denied = mcp_bridge.execute_tool("fixture", "change", {"value": "x"}, "analysis")
        self.assertEqual(read["status"], "completed")
        self.assertEqual(denied["status"], "permission_denied")

    def test_controlled_mutation_waits_for_approval_and_exact_call_runs_after(self):
        pending = mcp_bridge.execute_tool("fixture", "change", {"value": "exact"}, "controlled")
        self.assertEqual(pending["status"], "approval_required")
        approved = mcp_bridge.execute_tool("fixture", "change", {"value": "exact"}, "controlled", approved=True)
        self.assertEqual(approved["status"], "completed")
        self.assertIn("called:change", approved["output"])

    def test_unclassified_tool_is_denied(self):
        result = mcp_bridge.execute_tool("fixture", "not-allowed", {}, "autonomous")
        self.assertEqual(result["status"], "error")
        self.assertIn("nicht explizit freigegeben", result["message"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
