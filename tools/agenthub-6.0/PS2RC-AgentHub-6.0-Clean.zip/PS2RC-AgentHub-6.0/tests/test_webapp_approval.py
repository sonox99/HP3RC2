import sys
import unittest
from pathlib import Path
from unittest.mock import patch
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import webapp


class WebApprovalTests(unittest.TestCase):
    def tearDown(self):
        with webapp.job_lock:
            webapp.jobs.clear()


    def test_execute_job_forwards_selected_mode(self):
        job_id = uuid.uuid4().hex
        with webapp.job_lock:
            webapp.jobs[job_id] = {"status": "queued"}
        result = {
            "role": "coding", "goal": "write", "plan": "prepare",
            "review": "waiting", "decision": "awaiting_approval",
            "pending_actions": [{"tool": "write_file", "path": "x", "content": "y"}],
            "actions": [], "execution": [], "evidence": "", "report": "report.txt",
        }
        with patch.object(webapp.agenthub, "check_ollama"), \
             patch.object(webapp.agenthub, "route_model", return_value=("qwen3.5:9b", "worker")), \
             patch.object(webapp.agenthub, "run_developer_task", return_value=result) as run:
            webapp.execute_job(
                job_id,
                "prepare write",
                r"F:\\AI\\PS2RC-AgentHub-6.0",
                "controlled",
                "qwen3.5:9b",
                task_scope="project",
            )
        run.assert_called_once_with("prepare write", mode="controlled",
                                    workdir=r"F:\\AI\\PS2RC-AgentHub-6.0", model="qwen3.5:9b")
        with webapp.job_lock:
            job = webapp.jobs[job_id]
        self.assertEqual(job["status"], "awaiting_approval")
        self.assertEqual(job["pending_actions"], result["pending_actions"])

    def test_approval_executes_exact_saved_actions_without_replanning(self):
        job_id = uuid.uuid4().hex
        pending = [{
            "tool": "write_file",
            "path": r"F:\AI\PS2RC-AgentHub-6.0\approval-test.txt",
            "content": "approved exact bytes",
            "reason": "test",
        }]
        with webapp.job_lock:
            webapp.jobs[job_id] = {
                "status": "queued",
                "workdir": r"F:\AI\PS2RC-AgentHub-6.0",
                "pending_actions": pending,
                "result": {"mode": "controlled", "execution": [], "pending_actions": pending},
            }
        with patch.object(webapp.agenthub, "execute_approved_actions",
                          return_value=[{"tool": "write_file", "status": "completed"}]) as execute, \
             patch.object(webapp.agenthub, "run_developer_task",
                          side_effect=AssertionError("Approval must not start a new LLM plan")):
            webapp.execute_approved_job(job_id)
        execute.assert_called_once_with(pending, r"F:\AI\PS2RC-AgentHub-6.0", job_id=job_id)
        with webapp.job_lock:
            job = webapp.jobs[job_id]
        self.assertEqual(job["status"], "done")
        self.assertEqual(job["result"]["mode"], "controlled")
        self.assertEqual(job["pending_actions"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
