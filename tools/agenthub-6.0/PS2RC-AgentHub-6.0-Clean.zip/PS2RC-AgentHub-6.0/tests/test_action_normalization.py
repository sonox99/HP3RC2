import unittest
from unittest.mock import patch

import agenthub


class ActionNormalizationV511Tests(unittest.TestCase):
    def test_normalizes_flat_key_value_pairs_from_report(self):
        action = {
            "tool": "write_file",
            "reason": "controlled test",
            "args": [
                "path", "agenthub_control_test.txt",
                "content", "CONTROLLED_APPROVAL_TEST_2026",
                "mode", "controlled",
                "approved", "false",
            ],
            "mutates": False,
        }
        normalized = agenthub._normalize_action(action)
        self.assertEqual(normalized["path"], "agenthub_control_test.txt")
        self.assertEqual(normalized["content"], "CONTROLLED_APPROVAL_TEST_2026")
        self.assertTrue(normalized["_content_present"])
        self.assertEqual(normalized["_normalization_error"], "")

    def test_supports_legacy_labelled_arguments(self):
        normalized = agenthub._normalize_action({
            "tool": "write_file",
            "args": ["path: agenthub_control_test.txt", "content: CONTROLLED_APPROVAL_TEST_2026"],
        })
        self.assertEqual(normalized["path"], "agenthub_control_test.txt")
        self.assertEqual(normalized["content"], "CONTROLLED_APPROVAL_TEST_2026")
        self.assertEqual(normalized["_normalization_error"], "")

    def test_supports_canonical_fields_and_empty_content(self):
        normalized = agenthub._normalize_action({
            "tool": "write_file", "path": "empty.txt", "content": ""
        })
        self.assertEqual(normalized["path"], "empty.txt")
        self.assertEqual(normalized["content"], "")
        self.assertTrue(normalized["_content_present"])

    def test_rejects_conflicting_direct_and_args_values(self):
        normalized = agenthub._normalize_action({
            "tool": "write_file", "path": "safe.txt", "content": "safe",
            "args": ["path", "other.txt", "content", "different"],
        })
        self.assertIn("unterschiedliche Werte", normalized["_normalization_error"])

    def test_controlled_execution_uses_server_mode_and_builds_exact_pending_action(self):
        action = {
            "tool": "write_file",
            "reason": "controlled test",
            "args": [
                "path", "agenthub_control_test.txt",
                "content", "CONTROLLED_APPROVAL_TEST_2026",
                "mode", "autonomous",
                "approved", "true",
            ],
            "mutates": False,
        }
        expected = {
            "tool": "write_file", "status": "approval_required",
            "path": r"F:\AI\PS2RC-AgentHub-6.0\agenthub_control_test.txt",
            "message": "waiting",
        }
        with patch.object(agenthub.executor, "write_file", return_value=expected) as write:
            result = agenthub.developer_execute({
                "task": "create test file", "mode": "controlled",
                "workdir": r"F:\AI\PS2RC-AgentHub-6.0", "actions": [action],
            })
        write.assert_called_once_with(
            "agenthub_control_test.txt", "CONTROLLED_APPROVAL_TEST_2026",
            "controlled", base_dir=r"F:\AI\PS2RC-AgentHub-6.0"
        )
        self.assertTrue(result["execution"][0]["mutates"])
        self.assertEqual(result["decision"], "awaiting_approval")
        self.assertEqual(result["pending_actions"], [{
            "tool": "write_file",
            "path": r"F:\AI\PS2RC-AgentHub-6.0\agenthub_control_test.txt",
            "content": "CONTROLLED_APPROVAL_TEST_2026",
            "mutates": True,
            "reason": "controlled test",
        }])

    def test_ambiguous_action_is_denied_without_writing(self):
        action = {
            "tool": "write_file", "reason": "conflict",
            "path": "safe.txt", "content": "safe",
            "args": ["path", "other.txt", "content", "different"],
        }
        with patch.object(agenthub.executor, "write_file") as write:
            result = agenthub.developer_execute({
                "task": "create file", "mode": "controlled", "workdir": r"F:\AI\PS2RC-AgentHub-6.0",
                "actions": [action],
            })
        write.assert_not_called()
        self.assertEqual(result["execution"][0]["status"], "denied")
        self.assertFalse(result["pending_actions"])

    def test_approved_replay_revalidates_stored_path_and_content(self):
        expected = {"tool": "write_file", "status": "completed", "path": "safe.txt"}
        action = {"tool": "write_file", "path": "safe.txt", "content": "exact", "reason": "approved"}
        with patch.object(agenthub.executor, "write_file", return_value=expected) as write:
            result = agenthub.execute_approved_actions([action], r"F:\AI\PS2RC-AgentHub-6.0")
        write.assert_called_once_with(
            "safe.txt", "exact", "controlled",
            base_dir=r"F:\AI\PS2RC-AgentHub-6.0", approved=True
        )
        self.assertEqual(result[0]["status"], "completed")
        self.assertTrue(result[0]["mutates"])

    def test_approved_replay_rejects_missing_content(self):
        with patch.object(agenthub.executor, "write_file") as write:
            result = agenthub.execute_approved_actions(
                [{"tool": "write_file", "path": "safe.txt"}], r"F:\AI\PS2RC-AgentHub-6.0"
            )
        write.assert_not_called()
        self.assertEqual(result[0]["status"], "denied")


if __name__ == "__main__":
    unittest.main()
