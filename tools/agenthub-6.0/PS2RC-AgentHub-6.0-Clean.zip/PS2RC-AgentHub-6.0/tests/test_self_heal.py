from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from self_heal import RepairRejected, SelfHealingEngine


class SelfHealingEngineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "tests").mkdir()
        (self.root / "agenthub.py").write_text("VALUE = 1\n", encoding="utf-8")
        (self.root / "executor.py").write_text("SAFE = True\n", encoding="utf-8")
        self.engine = SelfHealingEngine(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def patch(self, name="agenthub.py"):
        return f"--- a/{name}\n+++ b/{name}\n@@ -1 +1 @@\n-VALUE = 1\n+VALUE = 2\n" if name == "agenthub.py" else (
            f"--- a/{name}\n+++ b/{name}\n@@ -1 +1 @@\n-SAFE = True\n+SAFE = False\n")

    def test_validate_and_stage_patch(self):
        changed = self.engine.validate_patch(self.patch())
        self.assertEqual(changed["agenthub.py"], "VALUE = 2\n")
        self.assertEqual((self.root / "agenthub.py").read_text(), "VALUE = 1\n")

    def test_protected_executor_is_rejected(self):
        with self.assertRaises(RepairRejected):
            self.engine.validate_patch(self.patch("executor.py"))

    def test_apply_requires_explicit_enablement(self):
        with self.assertRaises(RepairRejected):
            self.engine.apply_patch(self.patch())

    def test_memory_roundtrip(self):
        self.engine.remember("SyntaxError line 10", "missing bracket", "added bracket", "validated")
        result = self.engine.recall("SyntaxError line 10")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["diagnosis"], "missing bracket")


if __name__ == "__main__":
    unittest.main()
