import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import agenthub
import executor


class SearchFilesQueryFallbackTests(unittest.TestCase):
    def test_missing_query_is_recovered_from_task_context(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "root"
            root.mkdir()
            state = {
                "mode": "analysis",
                "workdir": str(root),
                "goal": "Diagnose the self-healing subsystem",
                "task": "Find configuration and Ollama connection references",
                "actions": [{"tool": "search_files", "reason": "Find relevant implementation"}],
            }
            with patch.object(executor, "search_files", return_value={
                "tool": "search", "status": "completed", "hits": []
            }) as search:
                result = agenthub.developer_execute(state)

            self.assertEqual(len(result["execution"]), 1)
            self.assertEqual(result["execution"][0]["status"], "completed")
            search.assert_called_once_with(
                "Diagnose the self-healing subsystem Find configuration and Ollama connection references"
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
