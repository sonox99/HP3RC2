import ast
import unittest
from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "agenthub.py").read_text(encoding="utf-8")
tree = ast.parse(source)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_structured_retry_budget")
module = ast.Module(body=[node], type_ignores=[])
ns = {"STRUCTURED_NUM_PREDICT": 2048, "MAX_STRUCTURED_RETRY_PREDICT": 4096, "CONTEXT_RESERVE_TOKENS": 1024}
exec(compile(module, "agenthub.py", "exec"), ns)
retry = ns["_structured_retry_budget"]

class ContextBudgetTests(unittest.TestCase):
    def test_512_budget_gets_one_2048_retry(self):
        self.assertEqual(retry(512, 1000, 24576), 2048)
    def test_retry_never_exceeds_maximum(self):
        self.assertEqual(retry(3072, 1000, 24576), 4096)
    def test_retry_refused_when_context_margin_is_insufficient(self):
        self.assertIsNone(retry(2048, 1024, 2048))
    def test_no_retry_when_already_at_maximum(self):
        self.assertIsNone(retry(4096, 1000, 24576))

if __name__ == "__main__":
    unittest.main(verbosity=2)
