from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

import self_heal_agent


class SelfHealPolicyTests(unittest.TestCase):
    def test_only_known_local_models_are_allowed(self):
        self.assertIn("qwen3.5:9b", self_heal_agent.ALLOWED_MODELS)
        self.assertNotIn("arbitrary-model", self_heal_agent.ALLOWED_MODELS)

    def test_patch_limit_is_bounded(self):
        self.assertEqual(self_heal_agent.MAX_PATCH_CHARS, 30000)

    def test_repair_entrypoint_exists_and_requires_explicit_mode_flag(self):
        # The web layer supplies auto_apply=True only for user-selected autonomous mode.
        import inspect
        signature = inspect.signature(self_heal_agent.repair_failure)
        self.assertIn("auto_apply", signature.parameters)
        self.assertFalse(signature.parameters["auto_apply"].default)


if __name__ == "__main__":
    unittest.main()
