from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import executor


class ExecutorV520Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.audit = self.root / "executor-test.jsonl"
        self.resolve_patch = patch.object(
            executor, "resolve_task_path",
            side_effect=lambda raw, base_dir=None: ((Path(base_dir or self.root) / raw).resolve(), [self.root]),
        )
        self.inside_patch = patch.object(executor, "_inside", return_value=True)
        self.log_patch = patch.object(executor, "LOG_PATH", self.audit)
        self.resolve_patch.start()
        self.inside_patch.start()
        self.log_patch.start()

    def tearDown(self):
        self.log_patch.stop()
        self.inside_patch.stop()
        self.resolve_patch.stop()
        self.temp.cleanup()

    def test_autonomous_write_is_atomic_and_verified(self):
        result = executor.write_file("new.txt", "AUTONOMOUS_OK", "autonomous", base_dir=self.root)
        self.assertEqual(result["status"], "completed")
        self.assertTrue(result["verified"])
        self.assertEqual((self.root / "new.txt").read_text(encoding="utf-8"), "AUTONOMOUS_OK")
        self.assertEqual(len(result["sha256"]), 64)

    def test_overwrite_creates_unique_backup_and_preserves_previous_content(self):
        target = self.root / "existing.txt"
        target.write_text("original", encoding="utf-8")
        first = executor.write_file("existing.txt", "revision-1", "autonomous", base_dir=self.root)
        second = executor.write_file("existing.txt", "revision-2", "autonomous", base_dir=self.root)
        self.assertEqual(first["status"], "completed")
        self.assertEqual(second["status"], "completed")
        self.assertNotEqual(first["backup"], second["backup"])
        self.assertEqual(Path(first["backup"]).read_text(encoding="utf-8"), "original")
        self.assertEqual(Path(second["backup"]).read_text(encoding="utf-8"), "revision-1")
        self.assertEqual(target.read_text(encoding="utf-8"), "revision-2")

    def test_controlled_mode_only_prepares(self):
        target = self.root / "pending.txt"
        result = executor.write_file("pending.txt", "WAIT", "controlled", base_dir=self.root)
        self.assertEqual(result["status"], "approval_required")
        self.assertFalse(target.exists())

    def test_analysis_mode_denies_write(self):
        target = self.root / "readonly.txt"
        result = executor.write_file("readonly.txt", "NO", "analysis", base_dir=self.root)
        self.assertEqual(result["status"], "permission_denied")
        self.assertFalse(target.exists())


if __name__ == "__main__":
    unittest.main()
