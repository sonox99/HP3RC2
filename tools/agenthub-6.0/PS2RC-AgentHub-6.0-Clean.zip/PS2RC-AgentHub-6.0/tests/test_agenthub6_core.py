from __future__ import annotations

import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from agenthub6.circuit import CircuitBreaker, CircuitOpenError
from agenthub6.config import load_env_file, load_runtime_config
from agenthub6.quality import citation_audit, response_integrity, validate_json_object_text
from agenthub6.rag import expand_queries, reciprocal_rank_fusion
from agenthub6.model_integrity import verify_model_digest
from agenthub6.routing import choose_model, task_complexity
from agenthub6.runtime import QueueFullError, RequestGate


class RuntimeConfigTests(unittest.TestCase):
    def test_env_file_does_not_override_process_environment(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / ".env"
            path.write_text("AGENTHUB_MAIN_NUM_CTX=4096\nAGENTHUB_KEEP_ALIVE='5m'\n", encoding="utf-8")
            with patch.dict(os.environ, {"AGENTHUB_MAIN_NUM_CTX": "8192"}, clear=False):
                os.environ.pop("AGENTHUB_KEEP_ALIVE", None)
                load_env_file(path)
                cfg = load_runtime_config()
                self.assertEqual(cfg.main.num_ctx, 8192)
                self.assertEqual(cfg.keep_alive, "5m")

    def test_runtime_values_are_clamped(self):
        with patch.dict(os.environ, {"AGENTHUB_MAIN_NUM_CTX": "999999", "AGENTHUB_MAIN_PARALLEL": "0"}):
            cfg = load_runtime_config()
        self.assertEqual(cfg.main.num_ctx, 131072)
        self.assertEqual(cfg.main.max_parallel, 1)


class RoutingTests(unittest.TestCase):
    def test_complex_project_routes_to_deep_model_when_installed(self):
        available = {"main": ["master", "deep"], "worker": ["worker", "fast"]}
        node, url = "main", "http://main"
        model, selected_node = choose_model(
            "Reverse engineering PS2 VU1 assembly root cause", "project", "auto",
            master="master", worker="worker", fast="fast", deep="deep",
            available=available, model_endpoints={"deep": url}, main_url=url, worker_url="http://worker",
        )
        self.assertEqual((model, selected_node), ("deep", node))

    def test_worker_offline_falls_back_to_main_for_auto(self):
        model, selected_node = choose_model(
            "quick question", "general", "auto", master="master", worker="worker",
            fast="fast", deep="deep", available={"main": ["master"], "worker": []},
            model_endpoints={}, main_url="http://main", worker_url="http://worker",
        )
        self.assertEqual((model, selected_node), ("master", "main"))

    def test_explicit_unavailable_model_is_not_silently_replaced(self):
        with self.assertRaisesRegex(RuntimeError, "Kein passendes Modell"):
            choose_model("quick", "general", "explicit", master="master", worker="worker",
                         fast="fast", deep="deep", available={"main": ["master"], "worker": []},
                         model_endpoints={}, main_url="http://main", worker_url="http://worker")

    def test_project_scope_is_deep(self):
        self.assertEqual(task_complexity("review this", "project"), "deep")


class QueueAndCircuitTests(unittest.TestCase):
    def test_queue_rejects_overflow(self):
        gate = RequestGate(max_active=1, max_queued=1)
        gate.acquire(0.1)
        finished = threading.Event()
        def waiter():
            gate.acquire(1.0)
            finished.set()
            gate.release()
        thread = threading.Thread(target=waiter)
        thread.start()
        time.sleep(0.05)
        with self.assertRaises(QueueFullError):
            gate.acquire(0.1)
        gate.release()
        thread.join(1.0)
        self.assertTrue(finished.is_set())
        self.assertEqual(gate.status()["active"], 0)

    def test_circuit_opens_and_resets_on_success(self):
        breaker = CircuitBreaker(threshold=2, reset_after=1)
        breaker.failure(); breaker.failure()
        self.assertEqual(breaker.status()["state"], "open")
        with self.assertRaises(CircuitOpenError):
            breaker.before_request()
        breaker.success()
        breaker.before_request()
        self.assertEqual(breaker.status()["state"], "closed")


class ModelIntegrityTests(unittest.TestCase):
    def test_digest_pin_detects_replaced_model_blob(self):
        pins = {"model:tag": {"digest": "expected", "node": "main"}}
        self.assertTrue(verify_model_digest("model:tag", "expected", pins)["ok"])
        self.assertFalse(verify_model_digest("model:tag", "changed", pins)["ok"])
        self.assertFalse(verify_model_digest("other:tag", "changed", pins)["pinned"])


class QualityAndRetrievalTests(unittest.TestCase):
    def test_citation_audit_detects_unknown_ids_and_missing_citations(self):
        audit = citation_audit("This is a long unsupported statement that is more than eighty characters and lacks evidence.",
                               "[E1] evidence")
        self.assertEqual(audit["invalid_ids"], [])
        self.assertEqual(audit["uncited_long_blocks"], 1)
        self.assertFalse(audit["semantic_support_verified"])
        invalid = citation_audit("claim [E9]", "[E1] evidence")
        self.assertEqual(invalid["invalid_ids"], ["E9"])

    def test_response_integrity_only_claims_truncation_check(self):
        result = response_integrity("complete", "<TRUNC>", "<WARN>")
        self.assertEqual(result["status"], "no_truncation_detected")
        self.assertFalse(result["semantic_correctness_verified"])

    def test_json_object_validator(self):
        self.assertTrue(validate_json_object_text('{"ok": true}')[0])
        self.assertFalse(validate_json_object_text('[1, 2]')[0])

    def test_query_expansion_retains_technical_identifiers(self):
        queries = expand_queries("Analysiere PS2RC VU1/DMAC loader_config.cpp")
        self.assertGreaterEqual(len(queries), 2)
        self.assertTrue(any("loader_config.cpp" in item for item in queries))

    def test_rrf_fuses_ranked_hits_without_comparing_raw_scores(self):
        a = [{"path": "a.cpp", "start_line": 1, "end_line": 10, "score": 100},
             {"path": "b.cpp", "start_line": 1, "end_line": 10, "score": 1}]
        b = [{"path": "b.cpp", "start_line": 1, "end_line": 10, "score": 1000}]
        result = reciprocal_rank_fusion([a, b], limit=2)
        self.assertEqual(result[0]["path"], "b.cpp")
        self.assertIn("rrf_score", result[0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
