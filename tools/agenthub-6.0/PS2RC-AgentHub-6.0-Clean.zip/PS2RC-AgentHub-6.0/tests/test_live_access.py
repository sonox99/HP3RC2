import os
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import project_index

class LiveReadTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "project"
        self.root.mkdir()
        self.root_patch = patch.object(project_index, "AGENTHUB_ROOT", self.root)
        self.project_patch = patch.object(project_index, "CONFIGURED_PROJECT_ROOT", self.root)
        self.root_patch.start()
        self.project_patch.start()
        (self.root / "README.md").write_text("# Live README\nOK\n", encoding="utf-8")

    def tearDown(self):
        self.project_patch.stop()
        self.root_patch.stop()
        self.tmp.cleanup()

    def test_reads_live_file(self):
        result = project_index.read_project_file(r".\README.md")
        self.assertTrue(result["ok"])
        self.assertEqual(Path(result["path"]), (self.root / "README.md").resolve())
        self.assertIn("Live README", result["content"])

    def test_rejects_parent_traversal(self):
        outside = Path(self.tmp.name) / "outside.txt"
        outside.write_text("no", encoding="utf-8")
        result = project_index.read_project_file("../outside.txt")
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "access_denied")
        self.assertEqual(result["checked_path"], str(outside.resolve()))

    def test_blocks_dotenv(self):
        (self.root / ".env.production").write_text("SECRET=x", encoding="utf-8")
        result = project_index.read_project_file(".env.production")
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "access_denied")

    def test_blocks_sensitive_directory(self):
        git = self.root / ".git"
        git.mkdir()
        (git / "config").write_text("credential", encoding="utf-8")
        result = project_index.read_project_file(".git/config")
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "access_denied")

    def test_reports_missing_on_disk_distinctly(self):
        result = project_index.read_project_file("missing.md")
        self.assertFalse(result["ok"])
        self.assertEqual(result["status"], "not_found")

    def test_absolute_inside_root(self):
        result = project_index.read_project_file(str(self.root / "README.md"))
        self.assertTrue(result["ok"])

    def test_task_workdir_is_used(self):
        work = self.root / "sub"
        work.mkdir()
        (work / "README.md").write_text("nested", encoding="utf-8")
        result = project_index.read_project_file(r".\README.md", base_dir=work)
        self.assertTrue(result["ok"])
        self.assertEqual(Path(result["path"]), (work / "README.md").resolve())

    def test_structured_operations(self):
        (self.root / "code.txt").write_text("alpha\nbeta\n", encoding="utf-8")
        listed = project_index.execute_structured_file_task("Get-ChildItem .")
        self.assertEqual(listed["result"]["status"], "listed")
        searched = project_index.execute_structured_file_task("Select-String -Path .\\code.txt -Pattern beta")
        self.assertEqual(searched["result"]["matches"][0]["line"], 2)
        metadata = project_index.execute_structured_file_task("Get-Item .\\code.txt")
        self.assertEqual(metadata["result"]["status"], "metadata")

if __name__ == "__main__":
    unittest.main(verbosity=2)
