import os
import sys
import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import agenthub
import project_index
import executor


class AgentHubControlTests(unittest.TestCase):
    def test_model_json_unescaped_newline_in_string_is_recovered(self):
        raw = '{"role":"coding","goal":"Read README\nthen report","reason":"inspection"}'
        parsed = agenthub.parse_json_object(raw, "test")
        self.assertEqual(parsed["goal"], "Read README\nthen report")

    def test_model_json_unescaped_tab_in_string_is_recovered(self):
        raw = '{"role":"coding","goal":"Read\tREADME","reason":"inspection"}'
        parsed = agenthub.parse_json_object(raw, "test")
        self.assertEqual(parsed["goal"], "Read\tREADME")

    def test_structured_task_is_evidence_not_shell(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "root"
            root.mkdir()
            (root / "README.md").write_text("hello live", encoding="utf-8")
            with patch.object(project_index, "AGENTHUB_ROOT", root.resolve()), \
                 patch.object(project_index, "CONFIGURED_PROJECT_ROOT", root.resolve()), \
                 patch.object(executor, "AGENTHUB_ROOT", root.resolve()):
                evidence = agenthub.retrieve_evidence(r"Get-Content .\README.md")
            self.assertIn("LIVE FILE TASK (read)", evidence)
            self.assertIn("hello live", evidence)

    def test_missing_file_lists_candidates_without_selecting_one(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "root"
            (root / "a").mkdir(parents=True)
            (root / "b").mkdir()
            (root / "a" / "README.md").write_text("a", encoding="utf-8")
            (root / "b" / "README.md").write_text("b", encoding="utf-8")
            with patch.object(project_index, "AGENTHUB_ROOT", root.resolve()), \
                 patch.object(project_index, "CONFIGURED_PROJECT_ROOT", root.resolve()):
                result = project_index.read_project_file("missing.md")
                candidates = project_index.read_project_file("README.md")
            self.assertEqual(result["status"], "not_found")
            self.assertEqual(result["candidates"], [])
            self.assertFalse(candidates["ok"])

    def test_fts_search_diversifies_files(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "root"
            root.mkdir()
            (root / "one.md").write_text("PLFS loader registry", encoding="utf-8")
            (root / "two.md").write_text("PLFS loader asset", encoding="utf-8")
            old_db = project_index.DB_PATH
            project_index.DB_PATH = Path(temp) / "index.sqlite3"
            try:
                with patch.object(project_index, "AGENTHUB_ROOT", root.resolve()):
                    project_index.build_index(root)
                hits = project_index.search_project("PLFS loader", limit=2)
            finally:
                project_index.DB_PATH = old_db
            self.assertEqual({hit["path"] for hit in hits}, {"one.md", "two.md"})

    def test_model_missing_is_explained(self):
        with patch.object(agenthub, "_models_for_endpoint", return_value=[{"name": "qwen3.5:9b", "digest": "x"}]):
            with self.assertRaisesRegex(RuntimeError, "nicht installiert"):
                agenthub.check_model_exists("missing:model")

    def test_reviewer_audit_rejects_unknown_citation(self):
        audit = agenthub.deterministic_audit("Fakt [E9]", "[E1] LIVE FILE: x\n---\ntext\n---")
        self.assertIn("Unbekannte Quellenkennungen: E9", audit)

    def test_review_evidence_is_compacted_and_chunked(self):
        evidence = "\n\n".join(f"[E{i}] LIVE FILE: file{i}.txt\n---\n{'x' * 3000}\n---" for i in range(1, 10))
        compact = agenthub.compact_review_evidence(evidence)
        self.assertLessEqual(len(compact), agenthub.REVIEW_EVIDENCE_CHARS + 80)
        self.assertGreater(len(agenthub.review_chunks(evidence)), 1)

    def test_ollama_request_parameters_and_length_marker(self):
        captured = {}
        response = {"message": {"content": "partial"}, "done_reason": "length",
                    "prompt_eval_count": 100, "eval_count": 16}
        with patch.object(agenthub, "check_model_exists"), patch.object(agenthub, "unload_other_models"), \
             patch.object(agenthub, "api_post_stream", side_effect=lambda path, payload, endpoint, request_id: captured.update(payload) or response):
            result = agenthub.ollama_chat(model="qwen3.5:9b", system="sys", user="user",
                                          think=False, num_predict=16)
        self.assertIn("Tokenlimit", result)
        self.assertEqual(captured["options"]["num_ctx"], agenthub.context_for_model("qwen3.5:9b"))
        self.assertEqual(captured["options"]["num_predict"], 64)
        self.assertFalse(captured["think"])

    def test_context_overflow_is_rejected_before_request(self):
        with patch.object(agenthub, "check_model_exists"), patch.object(agenthub, "unload_other_models"), \
             patch.object(agenthub, "api_post") as post:
            with self.assertRaisesRegex(RuntimeError, "Kontextbudget ueberschritten"):
                agenthub.ollama_chat(model="qwen3.5:9b", system="s" * 1000,
                                     user="u" * 90000, think=False, num_predict=1024)
        post.assert_not_called()

    def test_ollama_timeout_is_reported(self):
        import requests
        with patch.object(agenthub, "check_model_exists"), patch.object(agenthub, "unload_other_models"), \
             patch.object(agenthub, "api_post_stream", side_effect=RuntimeError("Ollama-Streaming-Timeout")):
            with self.assertRaisesRegex(RuntimeError, "Timeout"):
                agenthub.ollama_chat(model="qwen3.5:9b", system="sys", user="user",
                                     think=False, num_predict=16)

    def test_normal_review_uses_compact_input(self):
        state = {"task": "pruefe", "role": "debug", "specialist_answer": "Fakt [E1]",
                 "evidence": "[E1] LIVE FILE: x\n---\ntext\n---"}
        with patch.object(agenthub, "ollama_chat", return_value="review [E1]") as chat:
            result = agenthub.master_review(state)
        self.assertIn("review", result["review"])
        self.assertEqual(chat.call_count, 1)

    def test_review_retries_after_truncation(self):
        state = {"task": "pruefe", "role": "debug", "specialist_answer": "Fakt [E1]",
                 "evidence": "[E1] LIVE FILE: x\n---\ntext\n---"}
        with patch.object(agenthub, "ollama_chat", side_effect=[
                "abgeschnitten [WARNUNG: Tokenlimit erreicht; Antwort kann unvollstaendig sein.]",
                "kurze Fassung [E1]"]) as chat:
            result = agenthub.master_review(state)
        self.assertIn("REVIEW-RETRY", result["review"])
        self.assertEqual(chat.call_count, 2)


    def test_review_packet_preserves_relevant_evidence_across_file_and_strips_duplicate_payload(self):
        evidence_body = """# Project
Purpose: PS2RC AgentHub coordinates controlled development.
## Components
- Executor: allowlist, timeouts and audit logging.
- MCP client: local stdio integrations.
## Technical limitations
- No OS sandbox; child tools inherit process rights.
- HTTP/SSE transports are not supported.
## Installation
Install dependencies and start the browser.
Note: SQLite FTS5 is keyword search, not a semantic vector database.
"""
        evidence = (
            "[E1] LIVE FILE: README.md\n---\n" + evidence_body + "\n---\n\n"
            "[E2] ERFOLGREICHER LIVE-READ: README.md (POST-EXECUTION, LIVE)\n---\n"
            + evidence_body + "\n---"
        )
        state = {
            "task": "Summarize project purpose, main components and technical problems",
            "plan": "Read README and summarize it",
            "iteration": 1,
            "evidence": evidence,
            "execution": [{
                "tool": "read_file", "status": "read", "path": "README.md",
                "content": evidence_body, "bytes": len(evidence_body),
            }],
        }
        packet = agenthub._review_packet(state)
        self.assertIn("Purpose: PS2RC AgentHub", packet)
        self.assertIn("Executor: allowlist", packet)
        self.assertIn("No OS sandbox", packet)
        self.assertIn("HTTP/SSE transports", packet)
        self.assertIn("SQLite FTS5 is keyword search", packet)
        self.assertIn("content_chars", packet)
        self.assertNotIn('"content":', packet)
        self.assertEqual(packet.count("Purpose: PS2RC AgentHub"), 1)

    def test_developer_review_prompt_requires_answering_semantic_task_criteria(self):
        state = {
            "task": "Summarize purpose, components and technical limitations",
            "role": "coding",
            "mode": "analysis",
            "plan": "Read README",
            "iteration": 1,
            "evidence": "[E1] LIVE FILE: README.md\n---\nPurpose: Example\n---",
            "execution": [{"tool": "read_file", "status": "read", "path": "README.md"}],
        }
        captured = {}
        response = json.dumps({
            "decision": "done",
            "review": "Purpose: Example [E1]. Components and limitations are summarized.",
        })
        with patch.object(agenthub, "ollama_chat",
                          side_effect=lambda **kwargs: captured.update(kwargs) or response):
            result = agenthub.developer_review(state)
        self.assertEqual(result["decision"], "done")
        self.assertIn("semantisch", captured["system"])
        self.assertIn("direkt nutzbare Antwort", captured["system"])

    def test_controlled_write_action_ignores_model_mutates_false_and_replays_exactly(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "root"
            root.mkdir()
            state = {
                "mode": "controlled",
                "workdir": str(root),
                "actions": [{
                    "tool": "write_file",
                    "args": [f"path: {root / 'agenthub_control_test.txt'}",
                             "content: CONTROLLED_APPROVAL_TEST_2026"],
                    "mutates": False,
                    "reason": "controlled approval regression",
                }],
            }
            with patch.object(project_index, "AGENTHUB_ROOT", root.resolve()), \
                 patch.object(executor, "AGENTHUB_ROOT", root.resolve()):
                prepared = agenthub.developer_execute(state)
                target = root / "agenthub_control_test.txt"
                self.assertEqual(prepared["execution"][0]["status"], "approval_required")
                self.assertEqual(len(prepared["pending_actions"]), 1)
                self.assertFalse(target.exists())
                results = agenthub.execute_approved_actions(prepared["pending_actions"], str(root))
                self.assertEqual(results[0]["status"], "completed")
                self.assertEqual(target.read_text(encoding="utf-8"), "CONTROLLED_APPROVAL_TEST_2026")

    def test_developer_graph_has_bounded_success_path(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "root"
            root.mkdir()
            (root / "README.md").write_text("real evidence", encoding="utf-8")
            replies = [
                '{"role":"coding","goal":"Inspect README","plan":"Read the requested file","max_iterations":1}',
                # Match the observed production shape: path supplied in args[0].
                '{"actions":[{"tool":"read_file","args":["README.md"],"reason":"Verify live content","mutates":false}]}',
                '{"decision":"done","review":"Verified live content."}',
            ]
            with patch.object(project_index, "AGENTHUB_ROOT", root.resolve()), \
                 patch.object(project_index, "CONFIGURED_PROJECT_ROOT", root.resolve()), \
                 patch.object(executor, "AGENTHUB_ROOT", root.resolve()), \
                 patch.object(agenthub, "ollama_chat", side_effect=replies):
                result = agenthub.run_developer_task("Lies README.md", mode="analysis", workdir=str(root))
            self.assertEqual(result["decision"], "done")
            self.assertEqual(result["execution"][0]["status"], "read")


if __name__ == "__main__":
    unittest.main(verbosity=2)
