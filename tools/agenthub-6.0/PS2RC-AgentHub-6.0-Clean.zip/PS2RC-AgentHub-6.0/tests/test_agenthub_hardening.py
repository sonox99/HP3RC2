from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import project_index


class AgentHubBoundaryTests(unittest.TestCase):
    def test_environment_overrides_cannot_expand_filesystem_boundary(self):
        root = Path(project_index.AGENTHUB_ROOT).resolve()
        outside = Path(tempfile.gettempdir()).resolve()
        with patch.dict(os.environ, {
            "PS2RC_PROJECT_ROOT": str(outside),
            "PS2RC_TASK_WORKDIR": str(outside),
            "PS2RC_INDEX_DIR": str(outside),
        }):
            self.assertEqual(project_index.project_root(), root)
            self.assertEqual(project_index.task_workdir(), root)
            self.assertEqual(project_index.allowed_roots(), [root])
            self.assertEqual(project_index.DEFAULT_DATA, root / "data")


    def test_index_builder_rejects_external_root(self):
        with tempfile.TemporaryDirectory() as temp:
            outside = Path(temp).resolve()
            with self.assertRaisesRegex(PermissionError, "ausserhalb"):
                project_index.build_index(outside)

    def test_parent_traversal_is_outside_agenthub_root(self):
        root = Path(project_index.AGENTHUB_ROOT).resolve()
        target, roots = project_index.resolve_task_path("../outside.txt", root)
        self.assertNotEqual(target, root)
        self.assertFalse(any(target == r or r in target.parents for r in roots))


if __name__ == "__main__":
    unittest.main(verbosity=2)
