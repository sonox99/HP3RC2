from __future__ import annotations
import ast
import unittest
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / "agenthub.py"
TREE = ast.parse(SOURCE.read_text(encoding="utf-8"))
NODE = next(n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name == "ollama_chat_complete")

class ContinuationTests(unittest.TestCase):
    def _load(self, fake_chat):
        namespace = {"TRUNCATION_MARKER": "[WARNUNG: Tokenlimit erreicht; Antwort kann unvollstaendig sein.]",
                     "INTEGRITY_WARNING_MARKER": "[INTEGRITY_WARNING:",
                     "ollama_chat": fake_chat}
        exec(compile(ast.Module(body=[NODE], type_ignores=[]), str(SOURCE), "exec"), namespace)
        return namespace["ollama_chat_complete"]

    def test_continues_after_cutoff(self):
        marker = "[WARNUNG: Tokenlimit erreicht; Antwort kann unvollstaendig sein.]"
        calls = []
        def fake_chat(**kwargs):
            calls.append(kwargs)
            return "Teil 1" + marker if len(calls) == 1 else "Teil 2 fertig"
        complete = self._load(fake_chat)
        result = complete(model="m", system="s", user="u", think=False, num_predict=1000)
        self.assertEqual(result, "Teil 1\n\nTeil 2 fertig")
        self.assertEqual(len(calls), 2)
        self.assertIn("Setze direkt an der Abbruchstelle fort.", calls[1]["user"])

    def test_does_not_make_extra_call_when_complete(self):
        calls = []
        def fake_chat(**kwargs):
            calls.append(kwargs)
            return "Vollstaendige Antwort"
        complete = self._load(fake_chat)
        result = complete(model="m", system="s", user="u", think=False, num_predict=1000)
        self.assertEqual(result, "Vollstaendige Antwort")
        self.assertEqual(len(calls), 1)


    def test_continues_across_multiple_truncated_chunks(self):
        marker = "[WARNUNG: Tokenlimit erreicht; Antwort kann unvollstaendig sein.]"
        calls = []
        def fake_chat(**kwargs):
            calls.append(kwargs)
            if len(calls) == 1:
                return "Teil 1" + marker
            if len(calls) == 2:
                return "Teil 2" + marker
            return "Teil 3 fertig"
        complete = self._load(fake_chat)
        result = complete(model="m", system="s", user="u", think=False,
                          num_predict=1000, continuation_rounds=2)
        self.assertEqual(result, "Teil 1\n\nTeil 2\n\nTeil 3 fertig")
        self.assertEqual(len(calls), 3)

    def test_reports_when_last_continuation_is_still_truncated(self):
        marker = "[WARNUNG: Tokenlimit erreicht; Antwort kann unvollstaendig sein.]"
        calls = []
        def fake_chat(**kwargs):
            calls.append(kwargs)
            return f"Chunk {len(calls)}" + marker
        complete = self._load(fake_chat)
        result = complete(model="m", system="s", user="u", think=False,
                          num_predict=1000, continuation_rounds=2)
        self.assertEqual(len(calls), 3)
        self.assertIn("Antwort blieb nach den begrenzten", result)
        self.assertNotIn(marker, result)

if __name__ == "__main__":
    unittest.main(verbosity=2)
