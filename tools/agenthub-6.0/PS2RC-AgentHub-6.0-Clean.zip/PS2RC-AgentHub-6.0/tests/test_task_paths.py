import sys
import types
import unittest

# These are pure-parser tests; a tiny stub avoids requiring the optional LangGraph runtime here.
try:
    import langgraph.graph  # noqa: F401
except ImportError:
    lg = types.ModuleType("langgraph")
    graph = types.ModuleType("langgraph.graph")
    graph.END = "END"
    graph.START = "START"
    graph.StateGraph = object
    sys.modules["langgraph"] = lg
    sys.modules["langgraph.graph"] = graph

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
import agenthub

class TaskPathTests(unittest.TestCase):
    def test_get_content_dot_readme(self):
        self.assertEqual(agenthub.extract_requested_paths(r"Get-Content .\README.md"), [r".\README.md"])

    def test_get_content_raw_path(self):
        self.assertEqual(agenthub.extract_requested_paths(r"Get-Content -Raw -Path .\README.md"), [r".\README.md"])

    def test_nested_windows_path(self):
        self.assertEqual(agenthub.extract_requested_paths(r"Lies source\universal-ps2-recompiler\README.md"),
                         [r"source\universal-ps2-recompiler\README.md"])

    def test_relative_posix_path(self):
        self.assertEqual(agenthub.extract_requested_paths("Analysiere source/foo.cpp: PLFS path"), ["source/foo.cpp"])

    def test_absolute_windows_path(self):
        p = r"F:\PS2RC-HP3\source\loader.cpp"
        self.assertEqual(agenthub.extract_requested_paths("Lies " + p), [p])

if __name__ == "__main__":
    unittest.main(verbosity=2)
