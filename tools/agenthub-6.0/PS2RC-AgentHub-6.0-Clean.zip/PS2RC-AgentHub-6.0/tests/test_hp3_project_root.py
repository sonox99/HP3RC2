from __future__ import annotations
import importlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import project_index
import executor

class HP3ProjectRootTests(unittest.TestCase):
    def test_explicit_project_root_is_added_and_default_is_agenthub(self):
        original = os.environ.get("AGENTHUB_PROJECT_ROOT")
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp).resolve()
            with patch.dict(os.environ, {"AGENTHUB_PROJECT_ROOT": str(project)}):
                importlib.reload(project_index)
                importlib.reload(executor)
                self.assertEqual(project_index.project_root(), project)
                self.assertEqual(project_index.task_workdir(), project)
                self.assertIn(project, project_index.allowed_roots())
                self.assertTrue(executor._inside(project / "README.md"))
                self.assertFalse(executor._inside(Path(temp).parent / "outside.txt"))
        if original is None:
            os.environ.pop("AGENTHUB_PROJECT_ROOT", None)
        else:
            os.environ["AGENTHUB_PROJECT_ROOT"] = original
        importlib.reload(project_index)
        importlib.reload(executor)

    def test_legacy_ps2rc_environment_variables_do_not_expand_root(self):
        original = os.environ.get("AGENTHUB_PROJECT_ROOT")
        os.environ.pop("AGENTHUB_PROJECT_ROOT", None)
        with tempfile.TemporaryDirectory() as temp:
            with patch.dict(os.environ, {"PS2RC_PROJECT_ROOT": temp, "PS2RC_TASK_WORKDIR": temp}):
                importlib.reload(project_index)
                self.assertEqual(project_index.project_root(), project_index.AGENTHUB_ROOT)
                self.assertNotIn(Path(temp).resolve(), project_index.allowed_roots())
        if original is not None:
            os.environ["AGENTHUB_PROJECT_ROOT"] = original
        importlib.reload(project_index)

if __name__ == "__main__":
    unittest.main(verbosity=2)
