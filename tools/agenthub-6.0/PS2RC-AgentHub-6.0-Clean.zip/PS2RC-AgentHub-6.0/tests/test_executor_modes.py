import os
import sys
import tempfile
import unittest
import subprocess
from unittest.mock import patch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import executor
import project_index


class ExecutorV5Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / "project"
        self.root.mkdir()
        self.root_patch = patch.object(project_index, "AGENTHUB_ROOT", self.root)
        self.executor_root_patch = patch.object(executor, "AGENTHUB_ROOT", self.root)
        self.root_patch.start()
        self.executor_root_patch.start()

    def tearDown(self):
        self.executor_root_patch.stop()
        self.root_patch.stop()
        self.tmp.cleanup()

    def test_analysis_is_read_only(self):
        result = executor.write_file("new.txt", "x", "analysis", base_dir=self.root)
        self.assertEqual(result["status"], "permission_denied")
        self.assertFalse((self.root / "new.txt").exists())

    def test_controlled_prepares_without_writing(self):
        result = executor.write_file("new.txt", "x", "controlled", base_dir=self.root)
        self.assertEqual(result["status"], "approval_required")
        self.assertFalse((self.root / "new.txt").exists())

    def test_autonomous_write_creates_backup(self):
        target = self.root / "file.txt"
        target.write_text("old", encoding="utf-8")
        result = executor.write_file("file.txt", "new", "autonomous", base_dir=self.root)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(target.read_text(encoding="utf-8"), "new")
        self.assertTrue(Path(result["backup"]).exists())

    def test_allowlist_and_timeout(self):
        denied = executor.run_tool("unknown", [], self.root, "autonomous")
        self.assertEqual(denied["status"], "denied")

        class FakeProcess:
            returncode = None
            def __init__(self):
                self.killed = False
            def communicate(self, timeout=None):
                if timeout is not None:
                    raise subprocess.TimeoutExpired("cmake", timeout)
                return ("", "terminated")
            def kill(self):
                self.killed = True

        fake = FakeProcess()
        with patch.object(executor.shutil, "which", return_value="/usr/bin/cmake"), patch.object(executor.subprocess, "Popen", return_value=fake):
            timeout = executor.run_tool("cmake", ["--build", "."], self.root, "autonomous", timeout=1)
        self.assertEqual(timeout["status"], "timeout")
        self.assertTrue(fake.killed)


    def test_controlled_build_tool_is_prepared_with_exact_arguments(self):
        result = executor.run_tool("cmake", ["--build", "."], self.root, "controlled")
        self.assertEqual(result["status"], "approval_required")
        self.assertEqual(result["args"], ["--build", "."])
        self.assertEqual(result["cwd"], str(self.root))

    def test_git_mutating_commands_are_denied(self):
        result = executor.run_tool("git", ["reset", "--hard"], self.root, "autonomous")
        self.assertEqual(result["status"], "denied")

    def test_git_branch_delete_is_denied(self):
        result = executor.run_tool("git", ["branch", "-D", "main"], self.root, "autonomous")
        self.assertEqual(result["status"], "denied")

    def test_git_read_only_commands_are_allowed_to_resolve(self):
        result = executor.run_tool("git", ["status", "--short"], self.root, "analysis")
        self.assertIn(result["status"], {"completed", "failed", "not_available"})

    def test_arbitrary_python_is_denied(self):
        result = executor.run_tool("python", ["-c", "print('unsafe')"], self.root, "autonomous")
        self.assertEqual(result["status"], "denied")

    def test_git_snapshot_without_repository_is_explicit(self):
        result = executor.git_snapshot(self.root)
        self.assertEqual(result["status"], "not_available")


if __name__ == "__main__":
    unittest.main(verbosity=2)
