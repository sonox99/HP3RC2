[CmdletBinding()]
param(
    [ValidateSet('Main','Worker')][string]$Node = 'Main',
    [ValidateSet('User','Machine')][string]$Scope = 'User',
    [ValidateSet('f16','q8_0','q4_0')][string]$KVCacheType = 'q8_0',
    [ValidateRange(2048,131072)][int]$ContextLength,
    [ValidateRange(1,8)][int]$NumParallel = 1,
    [ValidateRange(1,16)][int]$MaxLoadedModels = 1,
    [ValidateRange(1,1024)][int]$MaxQueue = 32,
    [string]$KeepAlive = '10m',
    [switch]$DisableFlashAttention
)

$ErrorActionPreference = 'Stop'
if (-not $PSBoundParameters.ContainsKey('ContextLength')) {
    $ContextLength = if ($Node -eq 'Main') { 8192 } else { 8192 }
}
if ($Scope -eq 'Machine' -and -not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Machine-Scope benoetigt eine PowerShell als Administrator. Alternativ -Scope User verwenden.'
}

$values = [ordered]@{
    OLLAMA_NUM_PARALLEL = [string]$NumParallel
    OLLAMA_MAX_LOADED_MODELS = [string]$MaxLoadedModels
    OLLAMA_MAX_QUEUE = [string]$MaxQueue
    OLLAMA_KEEP_ALIVE = $KeepAlive
    OLLAMA_CONTEXT_LENGTH = [string]$ContextLength
    OLLAMA_LOAD_TIMEOUT = '10m'
    OLLAMA_FLASH_ATTENTION = if ($DisableFlashAttention) { '0' } else { '1' }
    OLLAMA_KV_CACHE_TYPE = $KVCacheType
}

$target = [EnvironmentVariableTarget]::$Scope
foreach ($entry in $values.GetEnumerator()) {
    [Environment]::SetEnvironmentVariable($entry.Key, $entry.Value, $target)
    Write-Host ("{0}={1}" -f $entry.Key, $entry.Value)
}

Write-Host ''
Write-Host ("Ollama-Konfiguration fuer {0} wurde im {1}-Scope gespeichert." -f $Node, $Scope) -ForegroundColor Green
Write-Warning 'Die Werte wirken erst nach einem vollstaendigen Neustart des Ollama-Prozesses bzw. Dienstes.'
Write-Host 'Ollama-Tray beenden und neu starten; bei Machine-Scope den Ollama-Dienst neu starten.'
Write-Host 'KV Q8_0 ist der konservative Qualitaets-/Speicher-Kompromiss. Q4_0 spart mehr Speicher, kann aber mehr Genauigkeit kosten.'
Write-Host 'Mehr Parallelitaet oder groessere Kontexte erhoehen den KV-Cache-Bedarf deutlich; zuerst mit 1 Parallel-Request testen.'
