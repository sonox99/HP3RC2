# AgentHub 6.0 – Startanleitung (Windows)

## 1. Installation

1. ZIP in einen neuen Ordner entpacken, z. B. `F:\AI\PS2RC-AgentHub-6.0`.
2. Python 3.12 und Ollama auf dem Main-PC installieren/starten. Den Worker-PC ebenfalls starten, sofern er verwendet werden soll.
3. `agenthub.env.example` nach `.env` kopieren.
4. In `.env` die Ollama-Adressen, die installierten Modell-Tags und `AGENTHUB_PROJECT_ROOT` kontrollieren. Die Beispieldatei enthält die zuletzt bekannte 2-PC-Konfiguration; sie prüft nicht, ob sich IPs oder Modell-Tags geändert haben.

## 2. Ollama auf beiden Rechnern optimieren

Das Skript muss auf jedem Ollama-Rechner ausgeführt werden. Auf dem Main-PC:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\Configure-Ollama-6.ps1 -Node Main -Scope User -KVCacheType q8_0
```

Auf dem Worker-PC die Release-Datei ebenfalls entpacken und dort ausführen:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\Configure-Ollama-6.ps1 -Node Worker -Scope User -KVCacheType q8_0
```

Danach Ollama vollständig beenden und neu starten. Das Skript stellt zunächst `NUM_PARALLEL=1`, `MAX_LOADED_MODELS=1`, Queue 32, Keep-Alive 10 Minuten, Kontext 8192, Flash Attention und KV-Cache Q8_0 ein. Das ist ein vorsichtiger Ausgangspunkt – kein garantiertes Optimum für jede Modell-/Ollama-Version. `q4_0` erst testen, wenn VRAM knapp ist; der geringere Speicherbedarf kann Qualität kosten.

## 3. AgentHub starten

`START-AGENTHUB.bat` starten. Beim ersten Aufruf legt es eine eigene `.venv` an und installiert die Python-Abhängigkeiten. Der Main-Ollama-Knoten ist erforderlich. Der Worker ist optional; bei Ausfall routet Auto auf ein verfügbares Main-Modell zurück. Das Webinterface bleibt lokal auf `http://127.0.0.1:8000` gebunden.

Danach `INDEX-HP3.bat` ausführen, damit der neue v6-Projektindex erstellt wird. Alte Datenbanken werden absichtlich nicht übernommen.

## 4. Modellrollen der Beispieldatei

| Rolle | Modell | Knoten | Zweck |
|---|---|---|---|
| Master | `qwen3:14b` | Main | Supervisor, Planung, Review |
| Worker | `gemma4:12b` | Worker | Worker-Aufgaben |
| Fast | `qwen3.5:9b` | Worker | schnelle Aufgaben / Self-Heal |
| Deep | `qwen3.8:27b-q4_K_M` | Main | komplexes Reverse Engineering |

Die Tags sind nur Defaults. Vor dem Start mit `ollama list` bzw. den `/api/tags`-Antworten abgleichen. Für Deep-Aufgaben kann das 27B-Modell auf der 12-GB-GPU teilweise in den Arbeitsspeicher ausweichen und dadurch deutlich langsamer werden.

## 5. Erste Checks

- `http://127.0.0.1:8000/api/status` zeigt Modellkatalog, Nodes, Inference-Runtime, Queue und Telemetrie.
- Im Webinterface über **Leistung** CPU/RAM/GPU/VRAM sowie Worker-Telemetrie öffnen.
- `AgentHub-Distributed-Benchmark.ps1` vergleicht Main und Worker einzeln und parallel. Kontext und Batch sind Parameter; die Standardwerte sind 8192/256.
- `AgentHub-E2E-Paralleltest.ps1` prüft den tatsächlichen AgentHub-Parallelworkflow. Beide Nodes müssen hierfür erreichbar sein.

## 6. Sicherheit und Daten

Das Release enthält keine `.env`, keine alten lokalen Datenbanken, keine Logs, keine virtuelle Python-Umgebung und keinen alten Cluster-Token. Für den Cluster-Monitor einen neuen zufälligen Token erzeugen und in `data/cluster-monitor.json` eintragen. MCP bleibt standardmäßig deaktiviert; vor Aktivierung jede Tool-Berechtigung prüfen.

Nicht jede theoretische Optimierung ist ein echter Ollama-Schalter: Prompt-/Prefix-Reuse wird vom Backend verwaltet; speculative decoding wird nicht als generische Option vorgetäuscht. Die Zitierprüfung kontrolliert Kennungen und Abdeckung, beweist aber nicht semantisch, dass eine Quelle die Aussage trägt.
