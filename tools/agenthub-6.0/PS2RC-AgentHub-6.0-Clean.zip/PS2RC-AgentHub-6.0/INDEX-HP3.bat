@echo off
setlocal
cd /d "%~dp0"
set "PYEXE=%~dp0.venv\Scripts\python.exe"
if not exist "%PYEXE%" set "PYEXE=python"
echo HP3-Projektindex wird erstellt: %AGENTHUB_PROJECT_ROOT%
"%PYEXE%" "%~dp0project_index.py" index --root "%AGENTHUB_PROJECT_ROOT%"
if errorlevel 1 (
  echo INDEX-FEHLER. Projektpfad und Berechtigungen pruefen.
  pause
  exit /b 1
)
echo Index fertig. AgentHub kann jetzt HP3-Quellen durchsuchen.
pause
