$ErrorActionPreference = 'Continue'
$Root = if ($env:AGENTHUB_PROJECT_ROOT) { $env:AGENTHUB_PROJECT_ROOT } else { 'F:\PS2RC-HP3' }
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
if (Test-Path -LiteralPath $Root -PathType Container) {
    $Diag = Join-Path $Root 'diagnostics\agenthub-preflight'
} else {
    $Diag = Join-Path $PSScriptRoot 'logs\hp3-preflight'
}
New-Item -ItemType Directory -Force -Path $Diag | Out-Null
$Report = Join-Path $Diag "HP3-BUILD-PREFLIGHT-$Stamp.txt"
$Lines = New-Object System.Collections.Generic.List[string]
function Add-Line([string]$Text) { $Lines.Add($Text) }
function Check-Command([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cmd) { Add-Line ("COMMAND {0}: FOUND - {1}" -f $Name, $cmd.Source) }
    else { Add-Line ("COMMAND {0}: MISSING" -f $Name) }
}
Add-Line 'HP3 BUILD PREFLIGHT - READ ONLY'
Add-Line ("Timestamp: {0}" -f (Get-Date -Format o))
Add-Line ("ProjectRoot: {0}" -f $Root)
Add-Line ''
if (-not (Test-Path -LiteralPath $Root -PathType Container)) {
    Add-Line 'FATAL: Project root does not exist.'
} else {
    Add-Line 'PROJECT ROOT: OK'
    Add-Line 'Top-level entries:'
    Get-ChildItem -LiteralPath $Root -Force -ErrorAction SilentlyContinue |
        Select-Object -First 80 | ForEach-Object { Add-Line ("  {0} [{1}]" -f $_.Name, $(if ($_.PSIsContainer) {'DIR'} else {'FILE'})) }
}
Add-Line ''
Add-Line 'TOOLS'
'git','cmake','ninja','python','py','psp-gcc','psp-ar','psp-ld','mips64r5900el-ps2-elf-gcc' | ForEach-Object { Check-Command $_ }
Add-Line ''
Add-Line 'TOOLCHAIN ENVIRONMENT'
foreach ($name in 'PSPDEV','PSPSDK','DEVKITPRO','DEVKITPPC','AGENTHUB_PROJECT_ROOT') {
    $value = [Environment]::GetEnvironmentVariable($name)
    Add-Line ("{0}: {1}" -f $name, $(if ($value) {$value} else {'NOT SET'}))
}
Add-Line ''
Add-Line 'COMMON PSP TOOLCHAIN PATHS'
$Candidates = @()
if ($env:PSPDEV) { $Candidates += (Join-Path $env:PSPDEV 'bin\psp-gcc.exe') }
if ($env:DEVKITPRO) { $Candidates += (Join-Path $env:DEVKITPRO 'devkitPSP\bin\psp-gcc.exe') }
$Candidates += @('C:\pspdev\bin\psp-gcc.exe','C:\devkitPro\devkitPSP\bin\psp-gcc.exe', (Join-Path $Root 'toolchain\bin\psp-gcc.exe'))
foreach ($candidate in ($Candidates | Select-Object -Unique)) {
    Add-Line ("{0}: {1}" -f $candidate, $(if (Test-Path -LiteralPath $candidate) {'FOUND'} else {'missing'}))
}
Add-Line ''
Add-Line 'KNOWN PCSX2 CONFIGURE DEPENDENCIES'
$SearchRoots = @((Join-Path $Root 'build'), (Join-Path $Root 'deps'), (Join-Path $Root 'third_party')) | Where-Object { Test-Path -LiteralPath $_ }
$Webp = @()
$DxDirs = @()
foreach ($searchRoot in $SearchRoots) {
    $Webp += Get-ChildItem -LiteralPath $searchRoot -Filter 'webp.lib' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 20
    $DxDirs += Get-ChildItem -LiteralPath $searchRoot -Directory -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^DirectX-Headers|directx-headers' } | Select-Object -First 20
}
if ($Webp.Count) { $Webp | ForEach-Object { Add-Line ("webp.lib: {0}" -f $_.FullName) } } else { Add-Line 'webp.lib: NOT FOUND in build/deps/third_party search roots' }
if ($DxDirs.Count) { $DxDirs | ForEach-Object { Add-Line ("DirectX-Headers directory: {0}" -f $_.FullName) } } else { Add-Line 'DirectX-Headers directory: NOT FOUND in build/deps/third_party search roots' }
Add-Line ''
Add-Line 'CMAKE CACHE SNAPSHOTS'
$CacheFiles = @()
$BuildRoot = Join-Path $Root 'build\pcsx2\build'
if (Test-Path -LiteralPath $BuildRoot) { $CacheFiles = Get-ChildItem -LiteralPath $BuildRoot -Filter 'CMakeCache.txt' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 10 }
if (-not $CacheFiles) { Add-Line 'No CMakeCache.txt found under build\pcsx2\build.' }
foreach ($cache in $CacheFiles) {
    Add-Line ("CACHE: {0}" -f $cache.FullName)
    Select-String -LiteralPath $cache.FullName -Pattern '^(CMAKE_HOME_DIRECTORY|CMAKE_GENERATOR|CMAKE_PREFIX_PATH|WEBP_LIBRARY|WebP_LIBRARY|DirectX-Headers_DIR|DirectX-Headers_SOURCE_DIR):' -ErrorAction SilentlyContinue |
        ForEach-Object { Add-Line ("  {0}" -f $_.Line) }
}
Add-Line ''
Add-Line 'RECENT BUILD LOGS'
$LogRoots = @((Join-Path $Root 'build'), (Join-Path $Root 'logs')) | Where-Object { Test-Path -LiteralPath $_ }
$RecentLogs = foreach ($logRoot in $LogRoots) { Get-ChildItem -LiteralPath $logRoot -File -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.log','.txt' } }
$RecentLogs | Sort-Object LastWriteTime -Descending | Select-Object -First 15 | ForEach-Object { Add-Line ("{0} | {1} bytes | {2}" -f $_.LastWriteTime, $_.Length, $_.FullName) }
Add-Line ''
Add-Line 'SAFETY: No build, install, delete, or configuration command was executed.'
$Lines | Set-Content -LiteralPath $Report -Encoding UTF8
Write-Host ($Lines -join [Environment]::NewLine)
Write-Host "`nReport saved: $Report" -ForegroundColor Green
