#requires -Version 5.1
<#
PS2RC-AgentHub – Distributed Ollama benchmark
- Read-only: sends inference requests only; does not modify AgentHub or project files.
- Tests Main and Worker independently, then concurrently.
- Performs one warm-up per node and three measured rounds by default.
#>

[CmdletBinding()]
param(
    [string]$MainUrl = "http://127.0.0.1:11434",
    [string]$WorkerUrl = "http://192.168.178.110:11434",
    [string]$MainModel = "qwen3:14b",
    [string]$WorkerModel = "gemma4:12b",
    [int]$Rounds = 3,
    [int]$NumPredict = 900,
    [int]$NumCtx = 8192,
    [int]$NumBatch = 256,
    [int]$TimeoutSec = 900,
    [string]$OutputDirectory = ".\benchmark-results"
)

$ErrorActionPreference = "Stop"

$Prompt = @'
Analysiere die Leistungsfähigkeit eines verteilten lokalen KI-Systems.
Bewerte ausschließlich anhand deiner eigenen Modellfähigkeiten:
1. Welche Aufgaben kannst du zuverlässig übernehmen?
2. Wo liegen typische Grenzen bei Analyse, Schlussfolgerungen und langen Antworten?
3. Welche Informationen wären nötig, um deine tatsächliche Laufzeit- und Hardwareleistung objektiv zu messen?
Antworte strukturiert und konkret in maximal 250 Wörtern.
Keine Dateiänderungen, keine Shell-Aktionen und keine erfundenen Messwerte.
'@

if ([string]::IsNullOrWhiteSpace($Prompt) -or $Prompt.Length -lt 100) {
    throw "Prompt unvollständig – Benchmark wird abgebrochen."
}
if ($Rounds -lt 1 -or $Rounds -gt 20) {
    throw "Rounds muss zwischen 1 und 20 liegen."
}
if ($NumPredict -lt 128) {
    throw "NumPredict muss mindestens 128 betragen."
}
if ($NumCtx -lt 2048 -or $NumCtx -gt 131072) { throw "NumCtx muss zwischen 2048 und 131072 liegen." }
if ($NumBatch -lt 1 -or $NumBatch -gt 4096) { throw "NumBatch muss zwischen 1 und 4096 liegen." }

$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$JsonPath = Join-Path $OutputDirectory "AgentHub-Benchmark-$Stamp.json"
$CsvPath  = Join-Path $OutputDirectory "AgentHub-Benchmark-$Stamp.csv"

function Invoke-OllamaTest {
    param(
        [string]$Name,
        [string]$Url,
        [string]$Model,
        [string]$TestPrompt,
        [int]$Predict,
        [int]$Context,
        [int]$Batch,
        [int]$Timeout
    )

    $body = @{
        model      = $Model
        prompt     = $TestPrompt
        stream     = $false
        think      = $false
        options    = @{
            num_ctx    = $Context
            num_batch  = $Batch
            num_predict = $Predict
        }
    }

    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $response = Invoke-RestMethod `
            -Uri ($Url.TrimEnd("/") + "/api/generate") `
            -Method Post `
            -ContentType "application/json" `
            -Body ($body | ConvertTo-Json -Depth 8) `
            -TimeoutSec $Timeout
        $timer.Stop()

        $evalSeconds = 0.0
        if ($response.eval_duration) {
            $evalSeconds = [double]$response.eval_duration / 1000000000.0
        }

        $tokensPerSecond = 0.0
        if ($evalSeconds -gt 0 -and $response.eval_count) {
            $tokensPerSecond = [math]::Round(([double]$response.eval_count / $evalSeconds), 2)
        }

        [pscustomobject]@{
            Name                = $Name
            Model               = $Model
            Url                 = $Url
            Success             = $true
            WallSeconds         = [math]::Round($timer.Elapsed.TotalSeconds, 2)
            TotalSeconds        = if ($response.total_duration) { [math]::Round(([double]$response.total_duration / 1e9), 2) } else { $null }
            LoadSeconds         = if ($response.load_duration) { [math]::Round(([double]$response.load_duration / 1e9), 2) } else { $null }
            PromptTokens        = $response.prompt_eval_count
            PromptEvalSeconds   = if ($response.prompt_eval_duration) { [math]::Round(([double]$response.prompt_eval_duration / 1e9), 2) } else { $null }
            OutputTokens        = $response.eval_count
            GenerationTokensSec = $tokensPerSecond
            Done                = $response.done
            DoneReason          = if ($response.done_reason) { [string]$response.done_reason } elseif ($response.done) { "done" } else { "unknown" }
            Response            = [string]$response.response
            Error               = $null
        }
    }
    catch {
        $timer.Stop()
        [pscustomobject]@{
            Name = $Name; Model = $Model; Url = $Url; Success = $false
            WallSeconds = [math]::Round($timer.Elapsed.TotalSeconds, 2)
            TotalSeconds = $null; LoadSeconds = $null; PromptTokens = $null
            PromptEvalSeconds = $null; OutputTokens = $null
            GenerationTokensSec = $null; Done = $false; DoneReason = "error"
            Response = $null; Error = $_.Exception.Message
        }
    }
}

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host " PS2RC-AgentHub – Distributed Ollama Benchmark"
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "Main:   $MainModel @ $MainUrl"
Write-Host "Worker: $WorkerModel @ $WorkerUrl"
Write-Host "Rounds: $Rounds | num_predict: $NumPredict | num_ctx: $NumCtx | num_batch: $NumBatch"
Write-Host "Prompt length: $($Prompt.Length) characters"
Write-Host "Output: $OutputDirectory"
Write-Host ""

$results = [System.Collections.Generic.List[object]]::new()

# Connectivity and model warm-up
foreach ($node in @(
    @{ Name = "Main"; Url = $MainUrl; Model = $MainModel },
    @{ Name = "Worker"; Url = $WorkerUrl; Model = $WorkerModel }
)) {
    Write-Host "Warm-up: $($node.Name) ..." -ForegroundColor Yellow
    $warm = Invoke-OllamaTest -Name ($node.Name + "-warmup") -Url $node.Url `
        -Model $node.Model -TestPrompt "Antworte nur mit: bereit" `
        -Predict 32 -Context $NumCtx -Batch $NumBatch -Timeout $TimeoutSec
    if (-not $warm.Success) {
        Write-Warning "$($node.Name) nicht erreichbar oder Modellfehler: $($warm.Error)"
    } else {
        Write-Host "  OK – $($warm.WallSeconds)s" -ForegroundColor Green
    }
    $results.Add($warm)
}

# Sequential baseline
for ($i = 1; $i -le $Rounds; $i++) {
    foreach ($node in @(
        @{ Name = "Main"; Url = $MainUrl; Model = $MainModel },
        @{ Name = "Worker"; Url = $WorkerUrl; Model = $WorkerModel }
    )) {
        Write-Host "Sequential Runde $i – $($node.Name) ..." -ForegroundColor Yellow
        $r = Invoke-OllamaTest -Name "$($node.Name)-sequential-$i" -Url $node.Url `
            -Model $node.Model -TestPrompt $Prompt -Predict $NumPredict -Context $NumCtx -Batch $NumBatch -Timeout $TimeoutSec
        $results.Add($r)
        if ($r.Success) {
            Write-Host "  $($r.GenerationTokensSec) tok/s | $($r.OutputTokens) Output-Tokens | $($r.DoneReason)" -ForegroundColor Green
        } else {
            Write-Warning "  Fehler: $($r.Error)"
        }
    }
}

# Concurrent runs – each node receives the same prompt independently.
for ($i = 1; $i -le $Rounds; $i++) {
    Write-Host "Parallel Runde $i – starte Main und Worker gleichzeitig ..." -ForegroundColor Cyan
    $parallelTimer = [System.Diagnostics.Stopwatch]::StartNew()

    $jobs = @()
    $jobs += Start-Job -ArgumentList $MainUrl, $MainModel, $Prompt, $NumPredict, $NumCtx, $NumBatch, $TimeoutSec, "Main-parallel-$i" -ScriptBlock {
        param($u, $m, $p, $n, $ctx, $batch, $t, $name)
        $ErrorActionPreference = "Stop"
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        try {
            $b = @{
                model = $m; prompt = $p; stream = $false; think = $false
                options = @{ num_ctx = $ctx; num_batch = $batch; num_predict = $n }
            }
            $x = Invoke-RestMethod -Uri ($u.TrimEnd("/") + "/api/generate") -Method Post `
                -ContentType "application/json" -Body ($b | ConvertTo-Json -Depth 8) -TimeoutSec $t
            $sw.Stop()
            $secs = if ($x.eval_duration) { [double]$x.eval_duration / 1e9 } else { 0 }
            [pscustomobject]@{
                Name = $name; Model = $m; Url = $u; Success = $true
                WallSeconds = [math]::Round($sw.Elapsed.TotalSeconds, 2)
                TotalSeconds = if ($x.total_duration) { [math]::Round(([double]$x.total_duration / 1e9), 2) } else { $null }
                LoadSeconds = if ($x.load_duration) { [math]::Round(([double]$x.load_duration / 1e9), 2) } else { $null }
                PromptTokens = $x.prompt_eval_count
                PromptEvalSeconds = if ($x.prompt_eval_duration) { [math]::Round(([double]$x.prompt_eval_duration / 1e9), 2) } else { $null }
                OutputTokens = $x.eval_count
                GenerationTokensSec = if ($secs -gt 0 -and $x.eval_count) { [math]::Round(([double]$x.eval_count / $secs), 2) } else { 0 }
                Done = $x.done
                DoneReason = if ($x.done_reason) { [string]$x.done_reason } elseif ($x.done) { "done" } else { "unknown" }
                Response = [string]$x.response; Error = $null
            }
        } catch {
            $sw.Stop()
            [pscustomobject]@{
                Name = $name; Model = $m; Url = $u; Success = $false
                WallSeconds = [math]::Round($sw.Elapsed.TotalSeconds, 2)
                TotalSeconds = $null; LoadSeconds = $null; PromptTokens = $null
                PromptEvalSeconds = $null; OutputTokens = $null
                GenerationTokensSec = $null; Done = $false; DoneReason = "error"
                Response = $null; Error = $_.Exception.Message
            }
        }
    }

    $jobs += Start-Job -ArgumentList $WorkerUrl, $WorkerModel, $Prompt, $NumPredict, $NumCtx, $NumBatch, $TimeoutSec, "Worker-parallel-$i" -ScriptBlock {
        param($u, $m, $p, $n, $ctx, $batch, $t, $name)
        $ErrorActionPreference = "Stop"
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        try {
            $b = @{
                model = $m; prompt = $p; stream = $false; think = $false
                options = @{ num_ctx = $ctx; num_batch = $batch; num_predict = $n }
            }
            $x = Invoke-RestMethod -Uri ($u.TrimEnd("/") + "/api/generate") -Method Post `
                -ContentType "application/json" -Body ($b | ConvertTo-Json -Depth 8) -TimeoutSec $t
            $sw.Stop()
            $secs = if ($x.eval_duration) { [double]$x.eval_duration / 1e9 } else { 0 }
            [pscustomobject]@{
                Name = $name; Model = $m; Url = $u; Success = $true
                WallSeconds = [math]::Round($sw.Elapsed.TotalSeconds, 2)
                TotalSeconds = if ($x.total_duration) { [math]::Round(([double]$x.total_duration / 1e9), 2) } else { $null }
                LoadSeconds = if ($x.load_duration) { [math]::Round(([double]$x.load_duration / 1e9), 2) } else { $null }
                PromptTokens = $x.prompt_eval_count
                PromptEvalSeconds = if ($x.prompt_eval_duration) { [math]::Round(([double]$x.prompt_eval_duration / 1e9), 2) } else { $null }
                OutputTokens = $x.eval_count
                GenerationTokensSec = if ($secs -gt 0 -and $x.eval_count) { [math]::Round(([double]$x.eval_count / $secs), 2) } else { 0 }
                Done = $x.done
                DoneReason = if ($x.done_reason) { [string]$x.done_reason } elseif ($x.done) { "done" } else { "unknown" }
                Response = [string]$x.response; Error = $null
            }
        } catch {
            $sw.Stop()
            [pscustomobject]@{
                Name = $name; Model = $m; Url = $u; Success = $false
                WallSeconds = [math]::Round($sw.Elapsed.TotalSeconds, 2)
                TotalSeconds = $null; LoadSeconds = $null; PromptTokens = $null
                PromptEvalSeconds = $null; OutputTokens = $null
                GenerationTokensSec = $null; Done = $false; DoneReason = "error"
                Response = $null; Error = $_.Exception.Message
            }
        }
    }

    $parallelResults = @()
    foreach ($job in $jobs) {
        $parallelResults += Receive-Job -Job $job -Wait
        Remove-Job -Job $job -Force
    }
    $parallelTimer.Stop()

    foreach ($r in $parallelResults) {
        $results.Add($r)
        if ($r.Success) {
            Write-Host "  $($r.Name): $($r.GenerationTokensSec) tok/s | $($r.OutputTokens) Tokens | $($r.DoneReason)" -ForegroundColor Green
        } else {
            Write-Warning "  $($r.Name): $($r.Error)"
        }
    }

    $results.Add([pscustomobject]@{
        Name = "Parallel-round-wall-$i"; Model = "combined"; Url = "-"
        Success = $true; WallSeconds = [math]::Round($parallelTimer.Elapsed.TotalSeconds, 2)
        TotalSeconds = $null; LoadSeconds = $null; PromptTokens = $null
        PromptEvalSeconds = $null; OutputTokens = $null; GenerationTokensSec = $null
        Done = $true; DoneReason = "parallel-wall-time"; Response = $null; Error = $null
    })
    Write-Host "  Gemeinsame Parallel-Laufzeit: $([math]::Round($parallelTimer.Elapsed.TotalSeconds, 2))s" -ForegroundColor Cyan
}

$results | ConvertTo-Json -Depth 6 | Set-Content -Path $JsonPath -Encoding UTF8
$results | Export-Csv -Path $CsvPath -NoTypeInformation -Encoding UTF8

Write-Host ""
Write-Host "================ Ergebnisübersicht ================" -ForegroundColor Cyan
$results |
    Where-Object { $_.Success -and $_.Name -notlike "*warmup*" -and $_.Name -notlike "Parallel-round-wall-*" } |
    Select-Object Name, Model, WallSeconds, OutputTokens, GenerationTokensSec, DoneReason |
    Format-Table -AutoSize

Write-Host "JSON: $JsonPath" -ForegroundColor Green
Write-Host "CSV:  $CsvPath" -ForegroundColor Green
Write-Host ""
Write-Host "Hinweis: Tokens/s sind Ollama-Generationswerte. GPU-Auslastung, VRAM, Netzwerk-RTT und echte Parallel-Skalierung müssen separat gemessen werden." -ForegroundColor Yellow
