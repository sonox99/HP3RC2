"""Built-in, dependency-free Windows hardware telemetry for AgentHub.

Samples ONLY the local/main PC. No Worker PC requests, Ollama calls, extra services,
package installs, power-limit changes or model configuration changes are performed.
"""
from __future__ import annotations
import csv, ctypes, os, shutil, subprocess, threading, time
from typing import Any
_CACHE_SECONDS=2.5
_cache_lock=threading.Lock()
_cache={"at":0.0,"value":None}
_cpu_lock=threading.Lock()
_cpu_previous=None

def _ft(v): return (int(v.dwHighDateTime)<<32)|int(v.dwLowDateTime)
def _cpu_percent():
    global _cpu_previous
    if os.name!="nt": return None
    try:
        from ctypes import wintypes
        idle,kernel,user=wintypes.FILETIME(),wintypes.FILETIME(),wintypes.FILETIME()
        if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)): return None
        cur=(_ft(idle),_ft(kernel),_ft(user))
        with _cpu_lock: prev=_cpu_previous; _cpu_previous=cur
        if prev is None: return None
        di=max(0,cur[0]-prev[0]); dk=max(0,cur[1]-prev[1]); du=max(0,cur[2]-prev[2]); total=dk+du
        return round(max(0.0,min(100.0,(total-di)*100.0/total)),1) if total else 0.0
    except Exception: return None

def _memory():
    empty={"percent":None,"used_gb":None,"total_gb":None}
    if os.name!="nt": return empty
    try:
        class M(ctypes.Structure):
            _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),("ullTotalPhys",ctypes.c_ulonglong),("ullAvailPhys",ctypes.c_ulonglong),("ullTotalPageFile",ctypes.c_ulonglong),("ullAvailPageFile",ctypes.c_ulonglong),("ullTotalVirtual",ctypes.c_ulonglong),("ullAvailVirtual",ctypes.c_ulonglong),("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
        m=M();m.dwLength=ctypes.sizeof(M)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)): return empty
        total=int(m.ullTotalPhys);used=total-int(m.ullAvailPhys)
        return {"percent":round(used*100.0/total,1) if total else None,"used_gb":round(used/1024**3,2),"total_gb":round(total/1024**3,2)}
    except Exception: return empty

def _num(v):
    try:
        v=(v or "").strip()
        return None if not v or v.upper() in {"N/A","[N/A]","NOT SUPPORTED"} else float(v)
    except (TypeError,ValueError): return None

def _gpu():
    exe=shutil.which("nvidia-smi")
    if not exe:return None
    fields="name,utilization.gpu,memory.used,memory.total,temperature.gpu,power.draw,power.limit"
    try:
        r=subprocess.run([exe,f"--query-gpu={fields}","--format=csv,noheader,nounits","--id=0"],capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=2.5,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),check=False)
        if r.returncode or not r.stdout.strip():return None
        row=next(csv.reader([r.stdout.strip().splitlines()[0]],skipinitialspace=True))
        if len(row)<7:return None
        return {"name":row[0].strip(),"utilization_percent":_num(row[1]),"memory_used_mib":_num(row[2]),"memory_total_mib":_num(row[3]),"temperature_c":_num(row[4]),"board_power_w":_num(row[5]),"board_power_limit_w":_num(row[6])}
    except (OSError,subprocess.SubprocessError,csv.Error):return None

def _sample():
    mem=_memory(); gpu=_gpu()
    host=os.environ.get("COMPUTERNAME") or (os.uname().nodename if hasattr(os,"uname") else "local")
    return {"scope":"main_pc_only","host":host,"timestamp":time.time(),"cpu_percent":_cpu_percent(),"ram_percent":mem["percent"],"ram_used_gb":mem["used_gb"],"ram_total_gb":mem["total_gb"],"gpu":gpu,"source":"Windows native APIs + nvidia-smi" if os.name=="nt" else "Windows-Sensoren nicht verfuegbar","note":"Nur Haupt-PC. GPU-Watt = Grafikkartenleistung, keine Messung des Gesamt-PCs/Netzteils. Worker-PC wird nicht abgefragt."}

def get_hardware_status()->dict[str,Any]:
    now=time.monotonic()
    with _cache_lock:
        value=_cache.get("value")
        if value is not None and now-float(_cache.get("at",0.0))<_CACHE_SECONDS:return dict(value)
        value=_sample();_cache["at"]=now;_cache["value"]=value
        return dict(value)