from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import requests

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "data" / "cluster-monitor.json"


def get_worker_status() -> dict[str, Any]:
    """Read-only, token-authenticated telemetry from the optional Worker monitor."""
    try:
        if not CONFIG_PATH.exists():
            return {"configured": False, "online": False, "error": "Worker-Monitor nicht installiert"}
        config = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))
        url = str(config.get("url", "http://192.168.178.110:8765")).rstrip("/")
        token = str(config.get("token", ""))
        if not token:
            return {"configured": False, "online": False, "error": "Worker-Token fehlt"}
        response = requests.get(
            url + "/metrics",
            headers={"X-AgentHub-Token": token},
            timeout=(0.8, 3.5),
        )
        response.raise_for_status()
        data = json.loads(response.content.decode("utf-8-sig"))
        data["configured"] = True
        data["online"] = True
        data["received_at"] = time.time()
        return data
    except Exception as exc:
        return {"configured": True, "online": False, "error": f"{type(exc).__name__}: {exc}"}
