"""Transactional self-repair primitives for PS2RC AgentHub.

Model output is treated as untrusted. Repairs are staged, validated and backed up.
This module deliberately does not execute arbitrary model-generated shell commands.
"""
from __future__ import annotations

import difflib
from contextlib import closing
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

DEFAULT_PROTECTED = {
    "executor.py", "mcp_bridge.py", "webapp.py", "self_heal.py",
}
ALLOWED_SUFFIXES = {".py", ".md", ".json", ".toml", ".yaml", ".yml", ".ini", ".cfg"}


@dataclass
class RepairResult:
    status: str
    message: str
    changed_files: list[str]
    test_output: str = ""
    backup_dir: str = ""


class RepairRejected(ValueError):
    pass


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _parse_unified_diff(patch: str) -> dict[str, str]:
    """Apply a conventional unified diff to original text, without shell/git."""
    lines = patch.splitlines(keepends=True)
    changes: dict[str, list[str]] = {}
    i = 0
    while i < len(lines):
        if not lines[i].startswith("--- "):
            i += 1
            continue
        old_name = lines[i][4:].strip().split("\t", 1)[0]
        i += 1
        if i >= len(lines) or not lines[i].startswith("+++ "):
            raise RepairRejected("Unified-Diff: Ziel-Datei (+++) fehlt.")
        new_name = lines[i][4:].strip().split("\t", 1)[0]
        i += 1
        if old_name.startswith("a/"):
            old_name = old_name[2:]
        if new_name.startswith("b/"):
            new_name = new_name[2:]
        if old_name != new_name or old_name == "/dev/null" or new_name == "/dev/null":
            raise RepairRejected("Dateien anlegen, löschen oder umbenennen sind in v1 nicht erlaubt.")
        if old_name.startswith(("/", "\\")) or ".." in Path(old_name).parts:
            raise RepairRejected(f"Unsicherer Patchpfad: {old_name}")
        hunks: list[str] = []
        while i < len(lines) and not lines[i].startswith("--- "):
            if lines[i].startswith("@@"):
                i += 1
                while i < len(lines) and not lines[i].startswith(("@@", "--- ")):
                    if lines[i].startswith((" ", "+", "-", "\\")):
                        hunks.append(lines[i])
                    else:
                        break
                    i += 1
            else:
                i += 1
        changes[old_name] = hunks
    if not changes:
        raise RepairRejected("Kein gültiger Unified-Diff gefunden.")

    # The diff parser above collects hunk bodies; apply in order per file.
    result: dict[str, str] = {}
    for name, body in changes.items():
        result[name] = "\0".join(body)
    return result


def _apply_hunks(original: str, body_blob: str) -> str:
    source = original.splitlines(keepends=True)
    body = body_blob.split("\0") if body_blob else []
    output: list[str] = []
    cursor = 0
    i = 0
    while i < len(body):
        hunk: list[str] = []
        while i < len(body) and body[i].startswith((" ", "+", "-", "\\")):
            hunk.append(body[i]); i += 1
        if not hunk:
            continue
        context = [x[1:] for x in hunk if x.startswith((" ", "-"))]
        found = None
        # Exact sequential matching; no fuzzy relocation to avoid accidental edits.
        for pos in range(cursor, len(source) - len(context) + 1):
            if source[pos:pos + len(context)] == context:
                found = pos
                break
        if found is None:
            raise RepairRejected("Patch-Kontext stimmt nicht exakt mit der Quelldatei überein.")
        output.extend(source[cursor:found])
        old_pos = found
        for line in hunk:
            if line.startswith(" "):
                output.append(source[old_pos]); old_pos += 1
            elif line.startswith("-"):
                old_pos += 1
            elif line.startswith("+"):
                output.append(line[1:])
        cursor = old_pos
    output.extend(source[cursor:])
    return "".join(output)


class SelfHealingEngine:
    def __init__(self, root: str | Path, *, memory_db: str | Path | None = None,
                 protected: Iterable[str] = DEFAULT_PROTECTED):
        self.root = Path(root).resolve()
        if not self.root.is_dir():
            raise FileNotFoundError(self.root)
        self.protected = set(protected)
        self.memory_db = Path(memory_db or self.root / "data" / "self_heal_memory.sqlite3")
        self.memory_db.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self):
        return sqlite3.connect(self.memory_db)

    def _init_db(self):
        # sqlite3.Connection as a context manager commits/rolls back, but does
        # NOT close the connection. Explicitly close it for Windows file cleanup.
        with closing(self._connect()) as db:
            with db:
                db.execute("""CREATE TABLE IF NOT EXISTS repair_memory (
                    id INTEGER PRIMARY KEY, created_at REAL NOT NULL, fingerprint TEXT NOT NULL,
                    symptom TEXT NOT NULL, diagnosis TEXT NOT NULL, patch_summary TEXT NOT NULL,
                    status TEXT NOT NULL, test_output TEXT NOT NULL)""")
                db.execute("CREATE INDEX IF NOT EXISTS idx_repair_fingerprint ON repair_memory(fingerprint)")

    @staticmethod
    def fingerprint(symptom: str) -> str:
        normalized = " ".join(symptom.lower().split())
        return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

    def remember(self, symptom: str, diagnosis: str, patch_summary: str,
                 status: str, test_output: str = "") -> None:
        with closing(self._connect()) as db:
            with db:
                db.execute("INSERT INTO repair_memory VALUES(NULL,?,?,?,?,?,?,?)",
                           (time.time(), self.fingerprint(symptom), symptom[:4000], diagnosis[:4000],
                            patch_summary[:4000], status[:80], test_output[-12000:]))

    def recall(self, symptom: str, limit: int = 5) -> list[dict[str, str]]:
        with closing(self._connect()) as db:
            rows = db.execute("SELECT symptom,diagnosis,patch_summary,status,test_output "
                              "FROM repair_memory WHERE fingerprint=? ORDER BY id DESC LIMIT ?",
                              (self.fingerprint(symptom), max(1, min(limit, 20)))).fetchall()
        return [dict(zip(("symptom", "diagnosis", "patch_summary", "status", "test_output"), row))
                for row in rows]

    def validate_patch(self, patch: str) -> dict[str, str]:
        parsed = _parse_unified_diff(patch)
        result: dict[str, str] = {}
        for relative, body in parsed.items():
            rel = Path(relative)
            target = (self.root / rel).resolve()
            if not _inside(target, self.root):
                raise RepairRejected(f"Pfad verlässt AgentHub-Root: {relative}")
            if relative.replace("\\", "/").split("/")[-1] in self.protected:
                raise RepairRejected(f"Geschützte Datei: {relative}")
            if target.suffix.lower() not in ALLOWED_SUFFIXES:
                raise RepairRejected(f"Dateityp nicht freigegeben: {relative}")
            if not target.is_file() or target.is_symlink():
                raise RepairRejected(f"Zieldatei fehlt oder ist Symlink: {relative}")
            original = target.read_text(encoding="utf-8")
            result[relative] = _apply_hunks(original, body)
        return result

    def test_patch(self, patch: str, *, test_command: list[str] | None = None,
                   timeout: int = 180) -> RepairResult:
        changes = self.validate_patch(patch)
        with tempfile.TemporaryDirectory(prefix="agenthub-selfheal-") as temp:
            stage = Path(temp) / "workspace"
            shutil.copytree(self.root, stage, ignore=shutil.ignore_patterns(
                ".venv", "venv", "__pycache__", ".git", "logs", "*.sqlite3"))
            for relative, content in changes.items():
                target = stage / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
            command = test_command or [os.environ.get("PYTHON", sys.executable), "-m", "unittest", "discover", "-s", "tests", "-v"]
            try:
                run = subprocess.run(command, cwd=stage, capture_output=True, text=True,
                                     timeout=timeout, shell=False)
            except subprocess.TimeoutExpired as exc:
                output = ((exc.stdout or "") + "\n" + (exc.stderr or ""))[-12000:]
                return RepairResult("failed", "Testlauf überschritt das Zeitlimit.", list(changes), output)
            output = (run.stdout + "\n" + run.stderr)[-12000:]
            if run.returncode != 0:
                return RepairResult("failed", f"Tests fehlgeschlagen (Exit {run.returncode}).",
                                    list(changes), output)
            return RepairResult("validated", "Patch in isolierter Kopie erfolgreich getestet.",
                                list(changes), output)

    def apply_patch(self, patch: str, *, test_command: list[str] | None = None,
                    allow_apply: bool = False, timeout: int = 180) -> RepairResult:
        if not allow_apply:
            raise RepairRejected("Übernahme gesperrt: allow_apply=True ist erforderlich.")
        changes = self.validate_patch(patch)
        tested = self.test_patch(patch, test_command=test_command, timeout=timeout)
        if tested.status != "validated":
            return tested
        backup = self.root / "backups" / "self-heal" / time.strftime("%Y%m%d-%H%M%S")
        backup.mkdir(parents=True, exist_ok=False)
        # Recheck originals immediately before applying to avoid overwriting concurrent edits.
        originals: dict[str, bytes] = {}
        for relative in changes:
            target = (self.root / relative).resolve()
            originals[relative] = target.read_bytes()
            (backup / relative).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup / relative)
        applied: list[Path] = []
        try:
            for relative, content in changes.items():
                target = (self.root / relative).resolve()
                if target.read_bytes() != originals[relative]:
                    raise RepairRejected(f"Datei wurde während der Prüfung geändert: {relative}")
                temp = target.with_suffix(target.suffix + ".selfheal.tmp")
                temp.write_text(content, encoding="utf-8")
                os.replace(temp, target)
                applied.append(target)
        except Exception:
            for target in applied:
                rel = str(target.relative_to(self.root))
                target.write_bytes(originals[rel])
            raise
        return RepairResult("applied", "Getesteter Patch übernommen.", list(changes),
                            tested.test_output, str(backup))
