#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$BaseUrl = "http://127.0.0.1:8000",
    [string]$Workdir = "F:\PS2RC-HP3",
    [int]$TimeoutMinutes = 30,
    [string]$MainModel = "qwen3:14b",
    [string]$WorkerModel = "gemma4:12b",
    [string]$OutputDirectory = ""
)
$ErrorActionPreference = "Stop"
if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $OutputDirectory = Join-Path $PSScriptRoot "benchmark-results"
}
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

$Task = @'
Analysiere den aktuell laufenden AgentHub-6.0-Parallelbetrieb anhand der beiden tatsächlich gelieferten Modellantworten und der Laufzeit-/Metadaten im Job-Ergebnis.
1. Vergleiche fachliche Richtigkeit, Vollständigkeit, Belegqualität und Unsicherheitskennzeichnung.
2. Trenne beobachtete Fakten von Annahmen; erfinde keine Hardware- oder Performance-Messwerte.
3. Benenne konkrete Widersprüche zwischen den beiden Antworten.
4. Empfiehl genau drei nächste HP3-Golden-Tests, mit denen sich die Modellqualität unterscheiden lässt.
Kein Shell-Zugriff, keine Dateiänderungen, keine erfundenen Quellen oder Messwerte.
'@
if ($Task.Length -lt 300) { throw "Testprompt unvollständig – Abbruch." }
if (-not (Test-Path -LiteralPath $Workdir -PathType Container)) { throw "Workdir nicht gefunden: $Workdir" }
$BaseUrl = $BaseUrl.TrimEnd("/")
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$JsonPath = Join-Path $OutputDirectory "AgentHub-E2E-$Stamp.json"
$TxtPath = Join-Path $OutputDirectory "AgentHub-E2E-$Stamp-summary.txt"

Write-Host "`n=== AgentHub End-to-End Paralleltest ===" -ForegroundColor Cyan
Write-Host "API: $BaseUrl | Workdir: $Workdir | Main: $MainModel | Worker: $WorkerModel | Dispatch: parallel"
$status = Invoke-RestMethod -Uri "$BaseUrl/api/status" -Method Get -TimeoutSec 10
if (-not $status.ollama) { throw "AgentHub meldet nicht beide Ollama-Nodes online." }
Write-Host "AgentHub $($status.version) | Main online: $($status.nodes.main.online) | Worker online: $($status.nodes.worker.online)"

$body = @{
    task = $Task
    workdir = $Workdir
    mode = "analysis"
    model = $MainModel
    dispatch_mode = "parallel"
    task_scope = "general"
}
$timer = [System.Diagnostics.Stopwatch]::StartNew()
$start = Invoke-RestMethod -Uri "$BaseUrl/api/chat" -Method Post -ContentType "application/json" `
    -Body ($body | ConvertTo-Json -Depth 8) -TimeoutSec 20
if (-not $start.job_id) { throw "AgentHub hat keine job_id zurückgegeben." }
$jobId = [string]$start.job_id
Write-Host "Job gestartet: $jobId" -ForegroundColor Green

$deadline = (Get-Date).AddMinutes($TimeoutMinutes)
$job = $null
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Milliseconds 1200
    $job = Invoke-RestMethod -Uri "$BaseUrl/api/job/$jobId" -Method Get -TimeoutSec 15
    if ($job.status -in @("queued", "running")) {
        Write-Host ("[{0:HH:mm:ss}] {1}" -f (Get-Date), $job.message) -ForegroundColor Yellow
        continue
    }
    break
}
$timer.Stop()
if (-not $job) { throw "Kein Jobstatus erhalten." }
if ($job.status -in @("queued", "running")) { throw "Timeout nach $TimeoutMinutes Minuten. Job-ID: $jobId" }
if ($job.status -ne "done") {
    $detail = if ($job.error) { $job.error } else { "Status: $($job.status)" }
    throw "AgentHub-Auftrag fehlgeschlagen: $detail"
}

$result = $job.result
if (-not $result) { throw "Job ist done, aber result fehlt." }
$parallel = $result.parallel_results
$mainAnswer = [string]$parallel.main.answer
$workerAnswer = [string]$parallel.worker.answer
$synthesis = [string]$result.answer

$checks = [ordered]@{
    JobDone = ($job.status -eq "done")
    MainRawAnswerPresent = (-not [string]::IsNullOrWhiteSpace($mainAnswer))
    WorkerRawAnswerPresent = (-not [string]::IsNullOrWhiteSpace($workerAnswer))
    MainModelCorrect = ([string]$parallel.main.model -eq $MainModel)
    WorkerModelCorrect = ([string]$parallel.worker.model -eq $WorkerModel)
    SupervisorSynthesis = (-not [string]::IsNullOrWhiteSpace($synthesis))
    ReadOnlyExecutionEmpty = (@($result.execution).Count -eq 0)
    PendingActionsEmpty = (@($result.pending_actions).Count -eq 0)
    ScopeGeneral = ([string]$result.task_scope -eq "general")
}
$passed = @($checks.Values | Where-Object { $_ -eq $true }).Count
$total = $checks.Count

$full = [ordered]@{
    timestamp = (Get-Date).ToString("o")
    job_id = $jobId
    status = $job.status
    elapsed_seconds = [math]::Round($timer.Elapsed.TotalSeconds, 2)
    agenthub_version = $status.version
    node_status = $status.nodes
    task_scope = $result.task_scope
    mode = $result.mode
    checks = $checks
    check_score = "$passed/$total"
    parallel_results = $parallel
    synthesis = $synthesis
    execution = $result.execution
    pending_actions = $result.pending_actions
    report = $result.report
    job_result = $result
}
$full | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $JsonPath -Encoding UTF8

$summary = @(
    "AGENTHUB END-TO-END PARALLELTEST"
    "Job-ID: $jobId"
    "Status: $($job.status)"
    "Laufzeit: $([math]::Round($timer.Elapsed.TotalSeconds,2)) Sekunden"
    "Checks: $passed/$total"
    ""
    "CHECKS:"
)
foreach ($key in $checks.Keys) { $summary += ("{0}: {1}" -f $key, $checks[$key]) }
$summary += @("", "MAIN RAW ANSWER ($($parallel.main.model)):", $mainAnswer, "",
    "WORKER RAW ANSWER ($($parallel.worker.model)):", $workerAnswer, "",
    "SUPERVISOR SYNTHESIS:", $synthesis, "", "AGENTHUB REPORT: $($result.report)")
$summary | Set-Content -LiteralPath $TxtPath -Encoding UTF8

Write-Host "`n=== Testergebnis ===" -ForegroundColor Cyan
foreach ($key in $checks.Keys) {
    $ok = [bool]$checks[$key]
    Write-Host ("{0,-28} {1}" -f $key, $ok) -ForegroundColor $(if ($ok) { "Green" } else { "Red" })
}
Write-Host "`nGesamt: $passed/$total Checks | Laufzeit: $([math]::Round($timer.Elapsed.TotalSeconds,2)) Sekunden"
Write-Host "JSON: $JsonPath"
Write-Host "TXT:  $TxtPath"
if ($passed -eq $total) {
    Write-Host "E2E-Dispatch technisch bestätigt." -ForegroundColor Green
} else {
    Write-Warning "Mindestens ein Pipeline-Check fehlgeschlagen. JSON und TXT zur Diagnose senden."
}
