# PS2RC AgentHub 6.0

Clean release of the PS2RC AgentHub runtime. This distribution contains the authoritative source once; it does not ship an old `payload` mirror, backup patchers, an old virtual environment, runtime logs, or machine-specific databases/secrets.

## Quick start (Windows 11)

1. Extract the ZIP to a short local folder, for example `F:\AI\PS2RC-AgentHub-6.0`.
2. Install Python 3.12 and Ollama on the Main PC. Start Ollama on the Worker PC if available.
3. Copy `agenthub.env.example` to `.env`; set the Main/Worker addresses and the actual installed model tags. The defaults are the model layout used during development, not a guarantee that your Ollama nodes still have those tags.
4. Edit the PS2RC project path in `.env` (`AGENTHUB_PROJECT_ROOT`).
5. Run `START-AGENTHUB.bat`. It creates a fresh `.venv`, installs only `requirements.txt`, checks Main Ollama, treats Worker as optional, and starts the web UI at `http://127.0.0.1:8000`.
6. Build the clean v6 FTS index with `INDEX-HP3.bat`. The v6 index is separate from any previous v3 database.

The first start needs Internet access for pip unless the two dependencies are already cached. Python 3.12 is recommended. No model files are included in the ZIP.

## Model roles and routing

`config/models.json` defines four default roles:

| Role | Default model | Node | Use |
|---|---|---|---|
| Master | `qwen3:14b` | Main | supervisor and final review |
| Worker | `gemma4:12b` | Worker | specialist work |
| Fast | `qwen3.5:9b` | Worker | quick requests and repair model |
| Deep | `qwen3.8:27b-q4_K_M` | Main | complex project / reverse engineering |

The model picker is discovered from `/api/tags`, so it reflects installed tags instead of a hard-coded two-entry list. `Auto` routes according to task scope and complexity; an explicitly selected model is never silently replaced. The deep 27B model is an escalation option: a 12 GB GPU may offload part of it to system RAM, so expect a higher cold-start and latency. Use the small/medium model for the normal supervisor path unless benchmark evidence supports a different default.

Override roles in `.env` with `AGENTHUB_MASTER_MODEL`, `AGENTHUB_WORKER_MODEL`, `AGENTHUB_FAST_MODEL`, and `AGENTHUB_DEEP_MODEL`. Set node mapping in `config/models.json` (`model_nodes`) if a model is moved to the other Ollama host. `AGENTHUB_SELF_HEAL_MODEL` sets the dedicated patch-diagnosis model; its node URL is `AGENTHUB_SELF_HEAL_OLLAMA_URL`.

For optional digest pinning, run `PIN-MODELS.py` after manually verifying the installed model versions. It writes `config/model-digests.json`; AgentHub then refuses to use a model tag whose digest changes. Re-running the script is an explicit pin update and creates a `.bak` copy first.

## Ollama server tuning

Run `scripts/Configure-Ollama-6.ps1` on each machine where Ollama runs:

```powershell
# Main node, standard user scope
.\scripts\Configure-Ollama-6.ps1 -Node Main -Scope User -KVCacheType q8_0

# Worker PC, standard user scope
.\scripts\Configure-Ollama-6.ps1 -Node Worker -Scope User -KVCacheType q8_0
```

It configures `OLLAMA_NUM_PARALLEL=1`, `OLLAMA_MAX_LOADED_MODELS=1`, `OLLAMA_MAX_QUEUE=32`, `OLLAMA_KEEP_ALIVE=10m`, `OLLAMA_CONTEXT_LENGTH=8192`, `OLLAMA_LOAD_TIMEOUT=10m`, `OLLAMA_FLASH_ATTENTION=1`, and `OLLAMA_KV_CACHE_TYPE=q8_0`. Restart the Ollama process/service after applying. Run as Administrator only for `-Scope Machine`.

`q8_0` is the conservative KV-cache default. `q4_0` reduces cache memory further but can reduce output quality. Flash Attention is enabled where the build/backend supports it. If Ollama reports an unsupported setting or startup issue, revert to `f16` or disable Flash Attention and retest. Context and parallelism multiply KV-cache demand; don't raise them blindly. AgentHub itself starts with 1 in-flight generation per node, 16 queued requests, 8k context and 256 batch tokens.

AgentHub also sends request-level `num_ctx`, `num_batch`, `num_predict` (capped by `AGENTHUB_MAX_NUM_PREDICT`), optional model-specific stop sequences, temperature/top-k/top-p/min-p, repeat controls, optional seed, and keep-alive. Server variables are read by Ollama only when its process starts; request options are handled per inference. Keep one loaded model warm by default. Forced unload-on-model-switch is disabled, because it increases repeated model load times. Set `AGENTHUB_UNLOAD_ON_SWITCH=1` only when memory pressure requires it.

## What is implemented in 6.0

- **Inference runtime:** per-node context, batch and concurrency; bounded queue, queue timeout, circuit breaker, HTTP connection reuse, streaming NDJSON, keep-alive, optional warmup, node/model discovery, explicit model eviction opt-in.
- **Sampling and output:** temperature, top-k, top-p, min-p, repeat penalty/last-n, seed, Mirostat controls (off by default), constrained JSON Schema through Ollama's format field, bounded structured-output retry and continuation for explicitly detected truncation.
- **Routing and orchestration:** task-complexity routing, master/worker/fast/deep roles, installed-model fallback for Auto, independent parallel analysis mode, self-repair restricted to a dedicated configured model and `agenthub.py` only.
- **RAG:** existing SQLite FTS5/BM25 search retained; query expansion and reciprocal-rank fusion replace direct comparison of raw scores; optional semantic retrieval via Ollama embeddings and a separate vector DB.
- **Reliability:** schema/structure constraints, input/output guards already present in tools, citation-ID and citation-coverage checks, truncation status, retry/timeouts, watchdog-style process/health information and bounded diagnostics. Approval gates for mutating tools remain in place.
- **Monitoring:** request ID, node, model, token counts, prompt/generation throughput, load and queue times, latency, completion reason, queue/circuit state and CPU pool status. Telemetry stores metrics only, never prompt text, responses or source documents.

## Optional semantic RAG

1. Pull a compatible embedding model on the Main Ollama node, for example `ollama pull nomic-embed-text`.
2. Set `AGENTHUB_EMBEDDING_MODEL=nomic-embed-text` in `.env`.
3. Run `INDEX-HP3-VECTORS.py` after the FTS index is built.

The vector database is stored separately as `data/agenthub-vectors-v6.sqlite3`. Without an embedding model, FTS5/BM25 remains the active retriever. The optional vector index must be rebuilt after the project source changes.

## Benchmarks and tuning workflow

Use `AgentHub-Distributed-Benchmark.ps1` and `AgentHub-E2E-Paralleltest.ps1` only after both nodes are configured. Compare identical fixed test prompts and record cold/warm latency, TTFT, end-to-end time, prompt/generation tok/s, peak VRAM/RAM, quality, citations and completeness. Change one parameter at a time. Keep a known-good baseline before increasing context, batch, or concurrency.

The release does not pretend to offer a universal model-specific Q4/Q5/Q6/Q8 benchmark: those quantizations are separate model artifacts and must be pulled and measured. Compare identical model families/instruct variants on the same golden test set. `qwen3.8:27b-q4_K_M` is a Q4 quantized artifact; Q5/Q6/Q8 variants are not included unless you install them yourself.

## Important Ollama limitations / deliberate non-fake features

- **Prompt/prefix caching:** Ollama manages prompt/KV reuse internally when applicable; this app has no separate documented public switch that can force cache hits. Identical stable system prefixes and keeping a model resident help reuse where the backend permits it. There is no fabricated `prefix_cache=true` flag.
- **Speculative decoding:** not enabled as a generic switch. It requires a compatible draft-model/backend path; this release does not invent an unsupported API option.
- **Stop sequences:** model-specific stop tokens are not globally injected by default because they can cut off code, JSON, or reasoning. Add tested stop sequences only for a specific model/profile.
- **vLLM, SGLang, llama.cpp, ExLlamaV2, TensorRT-LLM:** these are alternative serving backends, not Ollama toggles. The shipped runtime targets Ollama's `/api/chat` and `/api/embed` APIs.
- **Semantic correctness:** citation ID checks and truncation detection are deterministic; they are not proof that a cited passage entails a statement. A model reviewer can flag unsupported claims but is not a mathematically reliable verifier.
- **Automatic hyperparameter optimization / RLHF / DSPy / GEPA:** no opaque online self-tuning is run against production requests. Use the benchmark scripts and golden tests first; a tuning loop without reliable evaluation would overfit or silently reduce answer quality.

## Security and clean-release notes

- No `.env`, cluster token, local model cache, SQLite project index, telemetry database, logs, virtual environment or stale backups ship in this ZIP.
- MCP config is shipped as `config/mcp-servers.example.json`; copy it to `config/mcp-servers.json` and review every tool permission before enabling a server.
- Cluster monitor config is shipped as a template only. Generate a new random token and put it in `data/cluster-monitor.json`; do not reuse the token from the previous v5 ZIP.
- Tool execution approval gates remain unchanged. Keep the web UI on localhost unless you deliberately configure a secured reverse proxy/auth layer.

## Migration from v5.x

Stop the old AgentHub and extract v6 to a new folder. Do not copy the old `.venv`, `payload`, backups, `agenthub.py` backups, old SQLite databases or logs. Copy only reviewed local settings (URLs, model tags, project root and MCP configuration). Generate a new cluster monitor token. Build the new v6 index with `INDEX-HP3.bat`; the v6 index uses a new filename so old schema/data are not silently reused. Re-run the test suite and your HP3 golden prompts before enabling autonomous write mode.
