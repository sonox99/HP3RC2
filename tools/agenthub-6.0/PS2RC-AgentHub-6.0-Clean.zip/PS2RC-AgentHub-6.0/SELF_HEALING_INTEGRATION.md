# PS2RC AgentHub Self-Healing Integration

## Behavior
- A failed Developer-Graph job triggers a bounded Ollama repair attempt.
- The repair model may propose a unified diff for `agenthub.py` only.
- `executor.py`, `mcp_bridge.py`, `webapp.py`, and `self_heal.py` are protected.
- The patch is applied to a disposable copy and the full `unittest` suite is run.
- In `analysis` and `controlled` modes, a passing patch is recorded but NOT applied.
- In `autonomous` mode (which the user must select in the UI), a passing patch is backed up and applied.
- Failed tests, invalid diffs, unsupported files, or model errors never result in an apply.
- No shell tool or arbitrary command is exposed to the repair model.

## Memory
SQLite memory is stored at `data/self_heal_memory.sqlite3`. The memory records symptom,
diagnosis, patch summary, status, and test output. It is local and should be backed up
with the AgentHub data directory.

## Runtime
The AgentHub process needs `requests` and the same Python environment used to run its
test suite. Optionally set `AGENTHUB_PYTHON` to the Python executable used for tests.
Ollama must be reachable at `http://127.0.0.1:11434`.

## Important
A successfully applied `agenthub.py` patch affects the next process start; restart
AgentHub after the UI reports an applied repair. This integration does not automatically
modify protected permission, executor, MCP, or web-server files.
