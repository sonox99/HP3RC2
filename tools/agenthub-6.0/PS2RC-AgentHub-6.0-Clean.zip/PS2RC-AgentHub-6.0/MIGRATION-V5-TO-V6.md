# Migration from AgentHub v5.x to v6.0

1. Stop v5 AgentHub and Ollama-dependent jobs.
2. Extract AgentHub 6.0 to a new directory. Do not overlay the v5 installation.
3. Copy `agenthub.env.example` to `.env`; re-enter only verified URLs, model tags and the current project root.
4. Do not copy the old `.venv`, `payload`, patch scripts, backups, logs, SQLite DBs, or old cluster monitor token.
5. Copy MCP settings manually from the old config into `config/mcp-servers.json`, reviewing enabled tools and write permissions.
6. Create a new random cluster token if the cluster monitor is used, and configure `data/cluster-monitor.json` from the example template.
7. Apply `scripts/Configure-Ollama-6.ps1` separately on Main and Worker, then restart each Ollama process.
8. Run `START-AGENTHUB.bat`, verify the dynamic model inventory and check the inference runtime status.
9. Run `INDEX-HP3.bat` to rebuild the separate v6 FTS index. Optionally build vectors after setting an embedding model.
10. Run the regression suite and the HP3 golden dataset in analysis mode before switching on autonomous modifications.

The old v3 project-index database is intentionally not migrated because the v6 index is rebuilt from live source files. The old cluster token found in the v5 configuration is treated as compromised and must not be reused.
