from __future__ import annotations

import re
from collections import defaultdict
from typing import Any


def expand_queries(task: str) -> list[str]:
    """Deterministic query expansion for technical identifiers and compact terms."""
    original = re.sub(r"\s+", " ", (task or "")).strip()
    if not original:
        return []
    queries = [original]
    tokens = re.findall(r"[A-Za-z0-9_./\\:+-]{3,}", original)
    stop = {"analysiere", "analysieren", "zeige", "bitte", "warum", "welche", "welcher", "welches",
            "datei", "projekt", "kannst", "soll", "dass", "fuer", "und", "the", "and", "with"}
    compact = " ".join(dict.fromkeys(t for t in tokens if t.lower() not in stop))[:500]
    if compact and compact.lower() != original.lower():
        queries.append(compact)
    identifiers = [t for t in tokens if ("_" in t or "." in t or "/" in t or "\\" in t or ":" in t)]
    if identifiers:
        focused = " ".join(dict.fromkeys(identifiers))[:350]
        if focused.lower() not in {q.lower() for q in queries}:
            queries.append(focused)
    return queries[:3]


def reciprocal_rank_fusion(result_sets: list[list[dict[str, Any]]], limit: int = 12,
                            rank_constant: int = 60) -> list[dict[str, Any]]:
    """Merge BM25 result lists by rank, avoiding incomparable raw BM25 scores."""
    scores: dict[tuple[str, int, int], float] = defaultdict(float)
    values: dict[tuple[str, int, int], dict[str, Any]] = {}
    ranks: dict[tuple[str, int, int], list[int]] = defaultdict(list)
    for results in result_sets:
        for rank, item in enumerate(results, 1):
            key = (str(item.get("path", "")), int(item.get("start_line", 0)), int(item.get("end_line", 0)))
            scores[key] += 1.0 / (rank_constant + rank)
            ranks[key].append(rank)
            if key not in values:
                values[key] = dict(item)
    ordered = sorted(scores, key=lambda k: (-scores[k], k[0], k[1]))
    out: list[dict[str, Any]] = []
    seen_paths: set[str] = set()
    for key in ordered:
        item = values[key]
        # Diversify documents while retaining second passage if fewer than half the limit are available.
        if item["path"] in seen_paths and len(out) < max(2, limit // 2):
            continue
        item["rrf_score"] = round(scores[key], 8)
        item["retrieval_ranks"] = ranks[key]
        out.append(item)
        seen_paths.add(item["path"])
        if len(out) >= limit:
            break
    return out
