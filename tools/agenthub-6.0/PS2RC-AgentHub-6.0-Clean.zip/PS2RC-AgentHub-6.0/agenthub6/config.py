from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class NodeConfig:
    name: str
    url: str
    num_ctx: int
    num_batch: int
    max_parallel: int


@dataclass(frozen=True)
class RuntimeConfig:
    main: NodeConfig
    worker: NodeConfig
    keep_alive: str
    connect_timeout: float
    read_timeout: float
    queue_timeout: float
    max_queue: int
    stream: bool
    unload_on_switch: bool
    temperature: float
    top_p: float
    top_k: int
    min_p: float
    repeat_penalty: float
    repeat_last_n: int
    stop_sequences: tuple[str, ...]
    max_num_predict: int
    mirostat: int
    mirostat_tau: float
    mirostat_eta: float
    seed: int | None
    warmup_on_start: bool
    warmup_keep_alive: str


def load_env_file(path: str | Path) -> None:
    """Load a small KEY=VALUE .env file without overriding process variables."""
    env_path = Path(path)
    if not env_path.is_file():
        return
    try:
        lines = env_path.read_text(encoding="utf-8-sig").splitlines()
    except OSError:
        return
    for line in lines:
        value = line.strip()
        if not value or value.startswith("#") or "=" not in value:
            continue
        key, raw = value.split("=", 1)
        key = key.strip()
        raw = raw.strip()
        if not key or not key.replace("_", "").isalnum():
            continue
        if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in {"'", '"'}:
            raw = raw[1:-1]
        os.environ.setdefault(key, raw)


def _int(name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(low, min(high, value))


def _float(name: str, default: float, low: float, high: float) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(low, min(high, value))


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _json_string_list(name: str, default: list[str]) -> list[str]:
    raw = os.getenv(name, "").strip()
    if not raw:
        return list(default)
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return list(default)
    if not isinstance(value, list):
        return list(default)
    return list(dict.fromkeys(str(x).strip() for x in value if isinstance(x, str) and str(x).strip()))


def load_runtime_config() -> RuntimeConfig:
    main_url = os.getenv("AGENTHUB_MAIN_OLLAMA_URL", os.getenv("AGENTHUB_OLLAMA_URL", "http://127.0.0.1:11434")).rstrip("/")
    worker_url = os.getenv("AGENTHUB_WORKER_OLLAMA_URL", "http://192.168.178.110:11434").rstrip("/")
    return RuntimeConfig(
        main=NodeConfig("main", main_url, _int("AGENTHUB_MAIN_NUM_CTX", 8192, 2048, 131072),
                        _int("AGENTHUB_MAIN_NUM_BATCH", 256, 32, 4096),
                        _int("AGENTHUB_MAIN_PARALLEL", 1, 1, 8)),
        worker=NodeConfig("worker", worker_url, _int("AGENTHUB_WORKER_NUM_CTX", 8192, 2048, 131072),
                          _int("AGENTHUB_WORKER_NUM_BATCH", 256, 32, 4096),
                          _int("AGENTHUB_WORKER_PARALLEL", 1, 1, 8)),
        keep_alive=os.getenv("AGENTHUB_KEEP_ALIVE", "10m"),
        connect_timeout=_float("AGENTHUB_CONNECT_TIMEOUT", 10.0, 1.0, 120.0),
        read_timeout=_float("AGENTHUB_READ_TIMEOUT", 900.0, 30.0, 7200.0),
        queue_timeout=_float("AGENTHUB_QUEUE_TIMEOUT", 180.0, 1.0, 1800.0),
        max_queue=_int("AGENTHUB_MAX_QUEUE", 16, 1, 512),
        stream=_bool("AGENTHUB_STREAMING", True),
        unload_on_switch=_bool("AGENTHUB_UNLOAD_ON_SWITCH", False),
        temperature=_float("AGENTHUB_TEMPERATURE", 0.15, 0.0, 2.0),
        top_p=_float("AGENTHUB_TOP_P", 0.9, 0.01, 1.0),
        top_k=_int("AGENTHUB_TOP_K", 40, 1, 200),
        min_p=_float("AGENTHUB_MIN_P", 0.05, 0.0, 1.0),
        repeat_penalty=_float("AGENTHUB_REPEAT_PENALTY", 1.05, 0.5, 2.0),
        repeat_last_n=_int("AGENTHUB_REPEAT_LAST_N", 128, 0, 4096),
        stop_sequences=tuple(x[:256] for x in _json_string_list("AGENTHUB_STOP_SEQUENCES", [])[:16]),
        max_num_predict=_int("AGENTHUB_MAX_NUM_PREDICT", 8192, 128, 32768),
        mirostat=_int("AGENTHUB_MIROSTAT", 0, 0, 2),
        mirostat_tau=_float("AGENTHUB_MIROSTAT_TAU", 5.0, 0.1, 10.0),
        mirostat_eta=_float("AGENTHUB_MIROSTAT_ETA", 0.1, 0.001, 1.0),
        seed=(int(os.environ["AGENTHUB_SEED"]) if os.getenv("AGENTHUB_SEED", "").strip().lstrip("-").isdigit() else None),
        warmup_on_start=_bool("AGENTHUB_WARMUP_ON_START", False),
        warmup_keep_alive=os.getenv("AGENTHUB_WARMUP_KEEP_ALIVE", "10m"),
    )


def read_model_registry(path: str | Path) -> dict[str, Any]:
    """Load the shipped model routes; environment variables remain authoritative."""
    p = Path(path)
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}
