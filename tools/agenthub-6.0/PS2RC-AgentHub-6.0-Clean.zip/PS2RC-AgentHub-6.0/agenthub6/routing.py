from __future__ import annotations

import re
from typing import Any, Callable


def task_complexity(task: str, scope: str = "general") -> str:
    text = (task or "").lower()
    heavy = (
        "reverse engineering", "assembly", "vu1", "emotion engine", "ghidra", "disassembl",
        "architecture", "root cause", "ursachenanalyse", "mehrstufig", "refactor", "migration",
        "debug", "crash", "memory corruption", "race condition", "deadlock", "sicherheitsanalyse",
    )
    medium = ("powershell", "cmake", "c++", "python", "script", "build", "log", "firewall", "registry")
    if scope == "project" or any(x in text for x in heavy) or len(text) > 1800:
        return "deep"
    if any(x in text for x in medium) or len(text) > 650:
        return "balanced"
    return "fast"


def choose_model(task: str, scope: str, requested: str, *, master: str, worker: str,
                 fast: str, deep: str, available: dict[str, list[str]],
                 model_endpoints: dict[str, str], main_url: str, worker_url: str) -> tuple[str, str]:
    """Resolve auto routing and safe availability fallback, without silently changing explicit choices."""
    candidates: list[str]
    if requested and requested.lower() != "auto":
        candidates = [requested]
    else:
        level = task_complexity(task, scope)
        candidates = ([deep, master, worker] if level == "deep" else
                      [master, worker, fast] if level == "balanced" else
                      [worker, fast, master])
    for candidate in candidates:
        if not candidate:
            continue
        endpoint = model_endpoints.get(candidate, main_url if candidate in available.get("main", []) else worker_url)
        node = "worker" if endpoint.rstrip("/") == worker_url.rstrip("/") else "main"
        if candidate in available.get(node, []):
            return candidate, node
    raise RuntimeError(
        "Kein passendes Modell ist auf den konfigurierten Ollama-Knoten installiert. "
        "Pruefe /api/tags oder setze AGENTHUB_MASTER_MODEL bzw. AGENTHUB_WORKER_MODEL."
    )


def safe_task_label(task: str) -> str:
    return re.sub(r"\s+", " ", task or "").strip()[:160]
