from __future__ import annotations

import threading
import time
from typing import Any


class QueueFullError(RuntimeError):
    pass


class RequestGate:
    """Per-endpoint bounded FIFO-like gate with finite queue and wait timeout."""
    def __init__(self, max_active: int = 1, max_queued: int = 16):
        self.max_active = max(1, int(max_active))
        self.max_queued = max(1, int(max_queued))
        self._condition = threading.Condition()
        self._active = 0
        self._queued = 0
        self._completed = 0
        self._rejected = 0
        self._queue_wait_total = 0.0

    def acquire(self, timeout: float) -> float:
        started = time.perf_counter()
        deadline = started + max(0.0, timeout)
        with self._condition:
            if self._active >= self.max_active:
                if self._queued >= self.max_queued:
                    self._rejected += 1
                    raise QueueFullError("Ollama-Anfragewarteschlange ist voll. Bitte spaeter erneut versuchen.")
                self._queued += 1
                try:
                    while self._active >= self.max_active:
                        remaining = deadline - time.perf_counter()
                        if remaining <= 0:
                            self._rejected += 1
                            raise TimeoutError("Zeitlimit beim Warten auf einen freien Ollama-Slot erreicht.")
                        self._condition.wait(remaining)
                finally:
                    self._queued = max(0, self._queued - 1)
            self._active += 1
        waited = time.perf_counter() - started
        with self._condition:
            self._queue_wait_total += waited
        return waited

    def release(self) -> None:
        with self._condition:
            self._active = max(0, self._active - 1)
            self._completed += 1
            self._condition.notify()

    def status(self) -> dict[str, Any]:
        with self._condition:
            return {"active": self._active, "queued": self._queued,
                    "max_active": self.max_active, "max_queued": self.max_queued,
                    "completed": self._completed, "rejected": self._rejected,
                    "avg_queue_wait_sec": round(self._queue_wait_total / max(1, self._completed), 3)}
