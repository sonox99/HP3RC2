from __future__ import annotations

import re
from typing import Any


def citation_audit(answer: str, evidence: str) -> dict[str, Any]:
    valid = set(re.findall(r"\[(E\d+)\]", evidence or ""))
    used = set(re.findall(r"\[(E\d+)\]", answer or ""))
    invalid = sorted(used - valid)
    uncited_blocks = [p for p in re.split(r"\n\s*\n", answer or "")
                      if len(p.strip()) >= 80 and not re.search(r"\[E\d+\]", p)]
    return {
        "valid_ids": sorted(valid), "used_ids": sorted(used), "invalid_ids": invalid,
        "unused_ids": sorted(valid - used), "uncited_long_blocks": len(uncited_blocks),
        "syntactically_valid": not invalid,
        "semantic_support_verified": False,
        "note": "Der Audit prueft Kennungen und Zitierabdeckung, nicht die inhaltliche Belegpassung.",
    }


def response_integrity(answer: str, truncation_marker: str, integrity_marker: str,
                       evidence: str = "") -> dict[str, Any]:
    text = answer or ""
    truncated = truncation_marker in text or integrity_marker in text
    citations = citation_audit(text, evidence) if evidence else None
    return {
        "status": "incomplete" if truncated else "no_truncation_detected",
        "truncation_detected": truncated,
        "characters": len(text),
        "citations": citations,
        "semantic_correctness_verified": False,
    }


def validate_json_object_text(raw: str) -> tuple[bool, str]:
    import json
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        return False, str(exc)
    if not isinstance(value, dict):
        return False, "JSON-Wurzel muss ein Objekt sein."
    return True, "ok"
