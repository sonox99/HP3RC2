from __future__ import annotations

import math
import os
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any

import requests


class EmbeddingIndex:
    """Optional Ollama embedding index. Kept separate from the canonical FTS index."""
    def __init__(self, project_db: str | Path, vector_db: str | Path, model: str,
                 endpoint: str, timeout: tuple[float, float] = (10, 300)):
        self.project_db = Path(project_db)
        self.vector_db = Path(vector_db)
        self.model = model
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout
        self.vector_db.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.vector_db) as db:
            db.execute("""CREATE TABLE IF NOT EXISTS embeddings (
                chunk_id INTEGER PRIMARY KEY, sha256 TEXT NOT NULL, dimensions INTEGER NOT NULL,
                vector BLOB NOT NULL, updated_at REAL NOT NULL)""")
            db.execute("CREATE INDEX IF NOT EXISTS idx_embeddings_hash ON embeddings(sha256)")

    def _embed(self, texts: list[str]) -> list[list[float]]:
        response = requests.post(f"{self.endpoint}/api/embed",
                                 json={"model": self.model, "input": texts, "truncate": True},
                                 timeout=self.timeout)
        response.raise_for_status()
        payload = response.json()
        vectors = payload.get("embeddings")
        if not isinstance(vectors, list) or len(vectors) != len(texts):
            raise RuntimeError("Ollama /api/embed lieferte nicht die erwartete Anzahl Vektoren.")
        out = []
        for vector in vectors:
            if not isinstance(vector, list) or not vector:
                raise RuntimeError("Ollama lieferte einen leeren Embedding-Vektor.")
            out.append([float(x) for x in vector])
        return out

    def build(self, batch_size: int = 24, max_chunks: int | None = None) -> dict[str, Any]:
        if not self.project_db.is_file():
            raise FileNotFoundError(f"Projektindex fehlt: {self.project_db}")
        with sqlite3.connect(self.project_db) as source:
            query = "SELECT id,sha256,content FROM chunks ORDER BY id"
            if max_chunks:
                query += f" LIMIT {max(1, int(max_chunks))}"
            rows = source.execute(query).fetchall()
        written, skipped = 0, 0
        with sqlite3.connect(self.vector_db) as target:
            existing = {int(row[0]): str(row[1]) for row in target.execute("SELECT chunk_id,sha256 FROM embeddings")}
            for offset in range(0, len(rows), max(1, min(int(batch_size), 128))):
                batch = [row for row in rows[offset:offset + max(1, min(int(batch_size), 128))]
                         if existing.get(int(row[0])) != str(row[1])]
                skipped += len(rows[offset:offset + max(1, min(int(batch_size), 128))]) - len(batch)
                if not batch:
                    continue
                vectors = self._embed([str(row[2])[:12000] for row in batch])
                records = []
                for (chunk_id, digest, _content), vector in zip(batch, vectors):
                    blob = struct.pack(f"<{len(vector)}f", *vector)
                    records.append((int(chunk_id), str(digest), len(vector), blob, time.time()))
                target.executemany("INSERT OR REPLACE INTO embeddings VALUES(?,?,?,?,?)", records)
                target.commit()
                written += len(records)
        return {"model": self.model, "candidate_chunks": len(rows), "embedded": written,
                "unchanged": skipped, "database": str(self.vector_db)}

    def search(self, query: str, limit: int = 12) -> list[dict[str, Any]]:
        if not self.project_db.is_file() or not self.vector_db.is_file():
            return []
        q = self._embed([query])[0]
        q_norm = math.sqrt(sum(x * x for x in q)) or 1.0
        with sqlite3.connect(self.vector_db) as db:
            rows = db.execute("SELECT chunk_id,dimensions,vector FROM embeddings").fetchall()
        scored = []
        for chunk_id, dimensions, blob in rows:
            if int(dimensions) != len(q):
                continue
            vec = struct.unpack(f"<{dimensions}f", blob)
            norm = math.sqrt(sum(x * x for x in vec)) or 1.0
            score = sum(a * b for a, b in zip(q, vec)) / (q_norm * norm)
            scored.append((score, int(chunk_id)))
        scored.sort(reverse=True)
        selected = [item for _, item in scored[:max(1, min(limit * 3, 100))]]
        if not selected:
            return []
        with sqlite3.connect(self.project_db) as db:
            marks = ",".join("?" for _ in selected)
            records = db.execute(
                f"SELECT id,path,scope,start_line,end_line,content FROM chunks WHERE id IN ({marks})", selected
            ).fetchall()
        by_id = {int(row[0]): row for row in records}
        out = []
        for rank, chunk_id in enumerate(selected, 1):
            row = by_id.get(chunk_id)
            if not row:
                continue
            out.append({"path": row[1], "scope": row[2], "start_line": row[3], "end_line": row[4],
                        "content": row[5], "score": rank, "semantic_rank": rank})
            if len(out) >= limit:
                break
        return out


def configured_embedding_index(project_db: str | Path, vector_db: str | Path):
    model = os.getenv("AGENTHUB_EMBEDDING_MODEL", "").strip()
    if not model:
        return None
    endpoint = os.getenv("AGENTHUB_EMBEDDING_URL", os.getenv("AGENTHUB_MAIN_OLLAMA_URL", "http://127.0.0.1:11434"))
    return EmbeddingIndex(project_db, vector_db, model, endpoint,
                          (float(os.getenv("AGENTHUB_CONNECT_TIMEOUT", "10")),
                           float(os.getenv("AGENTHUB_EMBEDDING_TIMEOUT", "300"))))
