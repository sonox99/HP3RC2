from __future__ import annotations

import threading
import time


class CircuitOpenError(RuntimeError):
    pass


class CircuitBreaker:
    def __init__(self, threshold: int = 3, reset_after: float = 45.0):
        self.threshold = max(1, threshold)
        self.reset_after = max(1.0, reset_after)
        self._lock = threading.Lock()
        self._failures = 0
        self._opened_at = 0.0
        self._state = "closed"

    def before_request(self) -> None:
        with self._lock:
            if self._state != "open":
                return
            if time.monotonic() - self._opened_at >= self.reset_after:
                self._state = "half_open"
                return
            remaining = self.reset_after - (time.monotonic() - self._opened_at)
            raise CircuitOpenError(f"Ollama-Circuit offen; Retry in {remaining:.1f}s.")

    def success(self) -> None:
        with self._lock:
            self._failures = 0
            self._opened_at = 0.0
            self._state = "closed"

    def failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self.threshold or self._state == "half_open":
                self._state = "open"
                self._opened_at = time.monotonic()

    def status(self) -> dict[str, float | int | str]:
        with self._lock:
            return {"state": self._state, "failures": self._failures,
                    "reset_after_sec": self.reset_after}
