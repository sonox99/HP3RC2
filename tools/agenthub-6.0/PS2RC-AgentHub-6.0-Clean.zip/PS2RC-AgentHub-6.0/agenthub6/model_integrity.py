from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_digest_pins(path: str | Path) -> dict[str, dict[str, str]]:
    p = Path(path)
    if not p.is_file():
        return {}
    try:
        raw = json.loads(p.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return {}
    models = raw.get("models", {}) if isinstance(raw, dict) else {}
    if not isinstance(models, dict):
        return {}
    return {str(name): {"digest": str(value.get("digest", "")),
                        "node": str(value.get("node", ""))}
            for name, value in models.items() if isinstance(value, dict) and value.get("digest")}


def verify_model_digest(model: str, digest: str, pins: dict[str, dict[str, str]]) -> dict[str, Any]:
    expected = pins.get(model)
    if not expected:
        return {"pinned": False, "ok": True, "expected": None, "actual": digest}
    expected_digest = expected.get("digest", "")
    return {"pinned": True, "ok": expected_digest == digest,
            "expected": expected_digest, "actual": digest, "node": expected.get("node", "")}
