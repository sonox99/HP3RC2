from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any


class TelemetryStore:
    """Privacy-minimal metrics store: never persists prompts, replies, or source text."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS inference_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, request_id TEXT,
                node TEXT, model TEXT, task_type TEXT, prompt_tokens INTEGER, output_tokens INTEGER,
                prompt_tps REAL, generation_tps REAL, ttft_sec REAL, elapsed_sec REAL, load_sec REAL,
                queue_wait_sec REAL, finish TEXT, ok INTEGER NOT NULL, error_class TEXT)""")
            columns = {row[1] for row in db.execute("PRAGMA table_info(inference_events)")}
            if "ttft_sec" not in columns:
                db.execute("ALTER TABLE inference_events ADD COLUMN ttft_sec REAL")
            db.execute("CREATE INDEX IF NOT EXISTS idx_inference_ts ON inference_events(ts)")

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        return db

    def record(self, event: dict[str, Any]) -> None:
        fields = ("request_id", "node", "model", "task_type", "prompt_tokens", "output_tokens",
                  "prompt_tps", "generation_tps", "ttft_sec", "elapsed_sec", "load_sec", "queue_wait_sec",
                  "finish", "ok", "error_class")
        values = [event.get(k) for k in fields]
        with self._lock, self._connect() as db:
            db.execute(f"INSERT INTO inference_events(ts,{','.join(fields)}) VALUES({','.join('?' for _ in range(len(fields)+1))})",
                       [time.time(), *values])
            db.execute("DELETE FROM inference_events WHERE ts < ?", (time.time() - 90 * 86400,))

    def summary(self) -> dict[str, Any]:
        with self._connect() as db:
            rows = db.execute("SELECT COUNT(*) n, AVG(elapsed_sec) avg_latency, AVG(generation_tps) avg_tps, "
                              "SUM(CASE WHEN ok=0 THEN 1 ELSE 0 END) failures, "
                              "AVG(queue_wait_sec) avg_queue, AVG(ttft_sec) avg_ttft FROM inference_events").fetchone()
            recent = db.execute("SELECT ts,request_id,node,model,prompt_tokens,output_tokens,generation_tps,"
                                "elapsed_sec,load_sec,queue_wait_sec,finish,ok,error_class "
                                "FROM inference_events ORDER BY id DESC LIMIT 50").fetchall()
        return {"count": rows["n"], "avg_latency_sec": round(rows["avg_latency"] or 0, 3),
                "avg_generation_tps": round(rows["avg_tps"] or 0, 2),
                "avg_ttft_sec": round(rows["avg_ttft"] or 0, 3), "failures": rows["failures"] or 0,
                "avg_queue_wait_sec": round(rows["avg_queue"] or 0, 3),
                "recent": [dict(r) for r in recent]}
