from __future__ import annotations

import argparse
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

import requests
from agenthub6.config import load_env_file

ROOT = Path(__file__).resolve().parent
load_env_file(ROOT / ".env")


def main() -> int:
    parser = argparse.ArgumentParser(description="Pin installed AgentHub model digests from Ollama /api/tags")
    parser.add_argument("--output", type=Path, default=ROOT / "config" / "model-digests.json")
    args = parser.parse_args()
    nodes = {
        "main": os.getenv("AGENTHUB_MAIN_OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/"),
        "worker": os.getenv("AGENTHUB_WORKER_OLLAMA_URL", "http://192.168.178.110:11434").rstrip("/"),
    }
    records: dict[str, dict[str, str]] = {}
    for node, url in nodes.items():
        try:
            response = requests.get(url + "/api/tags", timeout=(5, 20))
            response.raise_for_status()
            for model in response.json().get("models", []):
                name, digest = str(model.get("name", "")), str(model.get("digest", ""))
                if name and digest:
                    if name in records and records[name]["digest"] != digest:
                        raise RuntimeError(f"Modelltag {name!r} hat auf beiden Knoten unterschiedliche Digests; bitte Modellnamen trennen.")
                    records[name] = {"node": node, "digest": digest}
        except Exception as exc:
            print(f"WARNUNG: {node} ({url}) nicht verfuegbar: {exc}")
    if not records:
        print("Keine Modell-Digests gefunden; nichts geschrieben.")
        return 2
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        backup = output.with_suffix(output.suffix + ".bak")
        shutil.copy2(output, backup)
        print(f"Vorherige Pins gesichert: {backup}")
    payload = {"generated_at": datetime.now(timezone.utc).isoformat(), "models": records}
    output.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"{len(records)} Modell-Digest(s) gepinnt: {output}")
    print("Wichtig: Pins nur nach bewusster Modellfreigabe neu erzeugen; dadurch wird ein Tag-Update akzeptiert.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
