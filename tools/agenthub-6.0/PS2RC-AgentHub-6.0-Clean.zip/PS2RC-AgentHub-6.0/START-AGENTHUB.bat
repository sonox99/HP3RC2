@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title PS2RC AgentHub 6.0

echo.
echo ==========================================
echo   PS2RC AgentHub 6.0 - CLEAN RELEASE
echo ==========================================
echo.

set "BASEPY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
set "BASEPY_ARGS="
if defined AGENTHUB_PYTHON if exist "%AGENTHUB_PYTHON%" set "BASEPY=%AGENTHUB_PYTHON%"
if not exist "%BASEPY%" (
    set "BASEPY="
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3.12 -c "import sys" >nul 2>&1
        if not errorlevel 1 (
            set "BASEPY=py"
            set "BASEPY_ARGS=-3.12"
        )
    )
)
if not defined BASEPY (
    echo FEHLER: Python 3.12 wurde nicht gefunden.
    pause
    exit /b 1
)

set "VENV=%~dp0.venv"
set "PYEXE=%VENV%\Scripts\python.exe"
if not exist "%PYEXE%" (
    echo Erstelle isolierte Python-Umgebung ...
    "%BASEPY%" %BASEPY_ARGS% -m venv "%VENV%"
    if errorlevel 1 (echo FEHLER beim Erstellen der .venv.& pause& exit /b 1)
)

"%PYEXE%" -c "import requests; import langgraph.graph" >nul 2>&1
if errorlevel 1 (
    echo Installiere feste Projekt-Abhaengigkeiten ...
    "%PYEXE%" -m pip install --upgrade pip
    if errorlevel 1 (echo FEHLER: pip-Upgrade fehlgeschlagen.& pause& exit /b 1)
    "%PYEXE%" -m pip install -r "%~dp0requirements.txt"
    if errorlevel 1 (echo FEHLER: Abhaengigkeiten konnten nicht installiert werden.& pause& exit /b 1)
)

if exist "%~dp0.env" (
    echo Verwende lokale .env-Konfiguration.
) else (
    echo INFO: Keine .env gefunden. Es gelten sichere Standardwerte.
    echo Beispiel: agenthub.env.example nach .env kopieren und anpassen.
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $envFile=Join-Path '%~dp0' '.env'; if(Test-Path $envFile){Get-Content -LiteralPath $envFile | ForEach-Object { $line=$_.Trim(); if($line -and -not $line.StartsWith('#') -and $line.Contains('=')){ $parts=$line.Split('=',2); $key=$parts[0].Trim(); $value=$parts[1].Trim().Trim('`"').Trim("'"); if($key){[Environment]::SetEnvironmentVariable($key,$value,'Process')} } }}; $main=if($env:AGENTHUB_MAIN_OLLAMA_URL){$env:AGENTHUB_MAIN_OLLAMA_URL}else{'http://127.0.0.1:11434'}; $worker=if($env:AGENTHUB_WORKER_OLLAMA_URL){$env:AGENTHUB_WORKER_OLLAMA_URL}else{'http://192.168.178.110:11434'}; try { $r=Invoke-RestMethod -Uri ($main+'/api/tags') -TimeoutSec 8; if(-not $r.models){throw 'Keine Modelle auf Main gefunden'}; Write-Host ('Main Ollama OK: '+$r.models.Count+' Modell(e)')} catch {Write-Host ('Main Ollama FEHLER: '+$_.Exception.Message); exit 1}; try { $r=Invoke-RestMethod -Uri ($worker+'/api/tags') -TimeoutSec 5; Write-Host ('Worker Ollama OK: '+$r.models.Count+' Modell(e)')} catch {Write-Warning 'Worker nicht erreichbar - AgentHub startet im Main-only-Modus.'}"
if errorlevel 1 (
    echo Main Ollama ist nicht erreichbar. Bitte Ollama auf dem Main-PC starten.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-NetTCPConnection -State Listen -LocalPort 8000 -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>&1
if not errorlevel 1 (
    echo AgentHub laeuft bereits auf http://127.0.0.1:8000
    start "" "http://127.0.0.1:8000"
    exit /b 0
)

echo.
echo AgentHub 6.0 wird gestartet. Fenster offen lassen.
echo URL: http://127.0.0.1:8000
echo Beenden mit STRG+C.
echo.
start "" "http://127.0.0.1:8000"
"%PYEXE%" "%~dp0webapp.py"
set "EXITCODE=%ERRORLEVEL%"
echo.
echo AgentHub beendet. Exitcode: %EXITCODE%
pause
exit /b %EXITCODE%
