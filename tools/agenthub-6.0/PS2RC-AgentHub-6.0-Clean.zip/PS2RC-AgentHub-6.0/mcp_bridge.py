"""Minimal MCP stdio client for explicitly configured local servers.

Only tools listed in read_only_tools or mutating_tools are exposed. The model
cannot choose a command, executable, server environment, or filesystem root.
MCP servers execute with the current Windows user's permissions: enable only
servers you trust.
"""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config" / "mcp-servers.json"
AUDIT_PATH = ROOT / "logs" / "mcp-audit.jsonl"
PROTOCOL_VERSION = "2024-11-05"
MAX_CONFIG_BYTES = 64 * 1024
MAX_TOOL_OUTPUT = 24_000
MAX_TOOL_ARGUMENT_BYTES = 64 * 1024
SERVER_TIMEOUT = 20


class MCPError(RuntimeError):
    pass


def _audit(event: dict[str, Any]) -> None:
    AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
    record = {"time": datetime.now().isoformat(timespec="seconds"), **event}
    with AUDIT_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    config_path = Path(path) if path else CONFIG_PATH
    if not config_path.exists():
        return {"servers": {}}
    if config_path.stat().st_size > MAX_CONFIG_BYTES:
        raise MCPError("MCP-Konfiguration ist groesser als 64 KB.")
    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MCPError(f"MCP-Konfiguration kann nicht gelesen werden: {exc}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("servers", {}), dict):
        raise MCPError("MCP-Konfiguration muss ein Objekt mit 'servers' enthalten.")
    if len(data.get("servers", {})) > 8:
        raise MCPError("Maximal acht MCP-Server sind erlaubt.")
    return data


def _server_spec(server_id: str, config: dict[str, Any] | None = None) -> dict[str, Any]:
    data = config if config is not None else load_config()
    servers = data.get("servers", {})
    if not isinstance(server_id, str) or server_id not in servers:
        raise MCPError(f"Unbekannter MCP-Server: {server_id}")
    spec = servers[server_id]
    if not isinstance(spec, dict) or spec.get("enabled") is not True:
        raise MCPError(f"MCP-Server '{server_id}' ist nicht aktiviert.")
    command = spec.get("command")
    args = spec.get("args", [])
    if not isinstance(command, str) or not command.strip():
        raise MCPError(f"MCP-Server '{server_id}' hat keinen gueltigen command.")
    if command.lower().endswith((".cmd", ".bat", ".ps1")):
        raise MCPError("MCP command darf keine .cmd/.bat/.ps1-Datei sein; nutze eine echte EXE wie node.exe oder python.exe.")
    if not isinstance(args, list) or len(args) > 50 or not all(isinstance(x, str) for x in args):
        raise MCPError(f"MCP-Server '{server_id}': args muss eine Liste aus maximal 50 Strings sein.")
    resolved = shutil.which(command)
    if resolved is None and Path(command).is_file():
        resolved = str(Path(command).resolve())
    if resolved is None:
        raise MCPError(f"MCP-Programm nicht gefunden: {command}")
    read_only = spec.get("read_only_tools", [])
    mutating = spec.get("mutating_tools", [])
    if not isinstance(read_only, list) or not isinstance(mutating, list):
        raise MCPError("read_only_tools und mutating_tools muessen Listen sein.")
    if not all(isinstance(x, str) and x for x in read_only + mutating):
        raise MCPError("MCP-Toolnamen muessen nichtleere Strings sein.")
    if len(set(read_only)) != len(read_only) or len(set(mutating)) != len(mutating):
        raise MCPError("Doppelte MCP-Toolnamen sind nicht erlaubt.")
    if set(read_only) & set(mutating):
        raise MCPError("Ein MCP-Tool darf nicht zugleich read-only und mutierend sein.")
    if len(set(read_only) | set(mutating)) > 100:
        raise MCPError("Maximal 100 explizit freigegebene MCP-Tools pro Server.")
    env = spec.get("env", {})
    if not isinstance(env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in env.items()):
        raise MCPError("MCP env muss ein String-zu-String-Objekt sein.")
    return {
        "id": server_id, "command": resolved, "args": args,
        "read_only_tools": set(read_only), "mutating_tools": set(mutating),
        "env": env, "timeout": max(3, min(int(spec.get("timeout", SERVER_TIMEOUT)), 60)),
    }


def config_status() -> dict[str, Any]:
    try:
        data = load_config()
        result = []
        for server_id, spec in data.get("servers", {}).items():
            if not isinstance(spec, dict):
                continue
            result.append({
                "id": server_id,
                "enabled": spec.get("enabled") is True,
                "read_only_tools": len(spec.get("read_only_tools", [])) if isinstance(spec.get("read_only_tools", []), list) else 0,
                "mutating_tools": len(spec.get("mutating_tools", [])) if isinstance(spec.get("mutating_tools", []), list) else 0,
            })
        return {"config": str(CONFIG_PATH), "servers": result, "error": ""}
    except Exception as exc:
        return {"config": str(CONFIG_PATH), "servers": [], "error": str(exc)}


def _child_env(extra: dict[str, str]) -> dict[str, str]:
    # Do not pass the complete user environment (which may contain API keys).
    allowed = {
        "PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "USERPROFILE",
        "APPDATA", "LOCALAPPDATA", "HOMEDRIVE", "HOMEPATH", "HOME", "TMPDIR",
    }
    env = {key: value for key, value in os.environ.items() if key.upper() in allowed}
    env.update(extra)
    return env


def _reader(pipe, target: queue.Queue) -> None:
    try:
        for line in iter(pipe.readline, ""):
            target.put(line)
    finally:
        target.put(None)


def _read_response(proc: subprocess.Popen, lines: queue.Queue, request_id: int, timeout: int) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise MCPError(f"MCP-Server antwortet nicht innerhalb von {timeout}s.")
        try:
            line = lines.get(timeout=remaining)
        except queue.Empty as exc:
            raise MCPError(f"MCP-Server-Timeout nach {timeout}s.") from exc
        if line is None:
            raise MCPError(f"MCP-Server hat stdout geschlossen (Exitcode {proc.poll()}).")
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except json.JSONDecodeError as exc:
            raise MCPError("MCP-Server sendet ungueltige JSON-Zeilen auf stdout. Server-Logs gehoeren nach stderr.") from exc
        if not isinstance(message, dict):
            continue
        if message.get("id") == request_id:
            if "error" in message:
                raise MCPError(f"MCP JSON-RPC Fehler: {message['error']}")
            result = message.get("result")
            if not isinstance(result, dict):
                raise MCPError("MCP-Server lieferte kein gueltiges result-Objekt.")
            return result


def _session(spec: dict[str, Any], call: tuple[str, dict[str, Any]] | None = None) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    proc = subprocess.Popen(
        [spec["command"], *spec["args"]],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace", bufsize=1, shell=False,
        env=_child_env(spec["env"]),
    )
    lines: queue.Queue = queue.Queue()
    stdout_thread = threading.Thread(target=_reader, args=(proc.stdout, lines), daemon=True)
    # Drain stderr independently to avoid a full pipe deadlocking the server.
    stderr_thread = threading.Thread(target=lambda: proc.stderr.read(), daemon=True)
    stdout_thread.start()
    stderr_thread.start()

    def send(message: dict[str, Any]) -> None:
        if proc.poll() is not None:
            raise MCPError(f"MCP-Server wurde beendet (Exitcode {proc.returncode}).")
        proc.stdin.write(json.dumps(message, ensure_ascii=False, separators=(",", ":")) + "\n")
        proc.stdin.flush()

    try:
        send({
            "jsonrpc": "2.0", "id": 1, "method": "initialize",
            "params": {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "ps2rc-agenthub", "version": "6.0.0"},
            },
        })
        _read_response(proc, lines, 1, spec["timeout"])
        send({"jsonrpc": "2.0", "method": "notifications/initialized"})
        send({"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}})
        listed = _read_response(proc, lines, 2, spec["timeout"])
        tools = listed.get("tools", [])
        if not isinstance(tools, list):
            raise MCPError("MCP tools/list lieferte keine Tool-Liste.")
        call_result = None
        if call is not None:
            name, arguments = call
            if not any(isinstance(tool, dict) and tool.get("name") == name for tool in tools):
                raise MCPError(f"MCP-Tool '{name}' ist auf dem Server nicht vorhanden.")
            send({
                "jsonrpc": "2.0", "id": 3, "method": "tools/call",
                "params": {"name": name, "arguments": arguments},
            })
            call_result = _read_response(proc, lines, 3, spec["timeout"])
        return tools, call_result
    finally:
        try:
            proc.kill()
        except OSError:
            pass
        try:
            proc.wait(timeout=2)
        except Exception:
            pass
        # Popen does not close its parent-side pipe handles when the child exits.
        # Close them explicitly so repeated short-lived MCP sessions do not leak
        # TextIOWrapper handles (or emit ResourceWarnings at interpreter exit).
        for pipe in (proc.stdin, proc.stdout, proc.stderr):
            if pipe is not None:
                try:
                    pipe.close()
                except OSError:
                    pass
        stdout_thread.join(timeout=1)
        stderr_thread.join(timeout=1)


def discover_tools() -> list[dict[str, Any]]:
    config = load_config()
    catalog: list[dict[str, Any]] = []
    for server_id, raw_spec in config.get("servers", {}).items():
        if not isinstance(raw_spec, dict) or raw_spec.get("enabled") is not True:
            continue
        spec = _server_spec(server_id, config)
        tools, _ = _session(spec)
        for tool in tools:
            if not isinstance(tool, dict):
                continue
            name = tool.get("name")
            if name in spec["read_only_tools"]:
                mutates = False
            elif name in spec["mutating_tools"]:
                mutates = True
            else:
                continue  # deny-by-default; unclassified tools are never exposed
            catalog.append({
                "server": server_id, "name": name,
                "description": str(tool.get("description", ""))[:1200],
                "inputSchema": tool.get("inputSchema", {"type": "object", "properties": {}}),
                "mutates": mutates,
            })
    return catalog[:200]


def execute_tool(server: str, name: str, arguments: dict[str, Any], mode: str,
                 approved: bool = False) -> dict[str, Any]:
    started = time.perf_counter()
    if mode not in {"analysis", "controlled", "autonomous"}:
        return {"tool": "mcp", "server": server, "name": name, "status": "denied",
                "message": "Unbekannter AgentHub-Modus."}
    try:
        spec = _server_spec(server)
        if not isinstance(arguments, dict):
            raise MCPError("MCP arguments muessen ein JSON-Objekt sein.")
        if len(json.dumps(arguments, ensure_ascii=False).encode("utf-8")) > MAX_TOOL_ARGUMENT_BYTES:
            raise MCPError("MCP-Toolargumente sind groesser als 64 KB.")
        if name in spec["read_only_tools"]:
            mutates = False
        elif name in spec["mutating_tools"]:
            mutates = True
        else:
            raise MCPError(f"MCP-Tool '{name}' ist nicht explizit freigegeben.")
        if mode == "analysis" and mutates:
            status = "permission_denied"
            result = {"tool": "mcp", "server": server, "name": name, "status": status,
                      "message": "Mutierende MCP-Tools sind im Analysemodus gesperrt."}
        elif mode == "controlled" and mutates and not approved:
            status = "approval_required"
            result = {"tool": "mcp", "server": server, "name": name, "status": status,
                      "arguments": arguments, "message": "MCP-Aktion vorbereitet; wartet auf Freigabe."}
        else:
            tools, raw = _session(spec, (name, arguments))
            if not any(isinstance(tool, dict) and tool.get("name") == name for tool in tools):
                raise MCPError(f"MCP-Tool '{name}' ist nicht mehr verfuegbar.")
            raw = raw or {}
            content_parts = []
            for item in raw.get("content", []) if isinstance(raw.get("content", []), list) else []:
                if isinstance(item, dict) and item.get("type") == "text":
                    content_parts.append(str(item.get("text", "")))
                elif isinstance(item, dict):
                    content_parts.append(f"[MCP-Inhalt: {item.get('type', 'unbekannt')}]")
            structured = raw.get("structuredContent")
            output = "\n".join(content_parts)
            if structured is not None:
                output += ("\n" if output else "") + json.dumps(structured, ensure_ascii=False, default=str)
            output = output[:MAX_TOOL_OUTPUT]
            status = "failed" if raw.get("isError") else "completed"
            result = {"tool": "mcp", "server": server, "name": name, "status": status,
                      "output": output, "isError": bool(raw.get("isError"))}
        _audit({
            "server": server, "name": name, "status": result["status"], "mode": mode,
            "approved": bool(approved), "argument_keys": sorted(arguments.keys()),
            "argument_bytes": len(json.dumps(arguments, ensure_ascii=False).encode("utf-8")),
            "duration_s": round(time.perf_counter() - started, 3),
        })
        return result
    except Exception as exc:
        result = {"tool": "mcp", "server": server, "name": name, "status": "error", "message": str(exc)}
        _audit({"server": server, "name": name, "status": "error", "mode": mode,
                "approved": bool(approved), "message": str(exc),
                "duration_s": round(time.perf_counter() - started, 3)})
        return result
