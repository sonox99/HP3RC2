from __future__ import annotations

import argparse
import hashlib
import os
import re
import sqlite3
from pathlib import Path
from typing import Iterator

from agenthub6.config import load_env_file
load_env_file(Path(__file__).resolve().parent / ".env")

AGENTHUB_ROOT = Path(__file__).resolve().parent.resolve()
# Explicit opt-in: only this single configured project root is added beside the
# AgentHub installation. Legacy PS2RC_* variables remain ignored.
_PROJECT_ROOT_RAW = os.environ.get("AGENTHUB_PROJECT_ROOT", "").strip()
if _PROJECT_ROOT_RAW:
    _candidate_root = Path(_PROJECT_ROOT_RAW).expanduser()
    if not _candidate_root.is_absolute():
        raise ValueError("AGENTHUB_PROJECT_ROOT muss ein absoluter Pfad sein.")
    CONFIGURED_PROJECT_ROOT = _candidate_root.resolve()
else:
    CONFIGURED_PROJECT_ROOT = AGENTHUB_ROOT
DEFAULT_PROJECT_ROOT = CONFIGURED_PROJECT_ROOT
DEFAULT_TASK_WORKDIR = CONFIGURED_PROJECT_ROOT
DEFAULT_ROOT = CONFIGURED_PROJECT_ROOT
DEFAULT_DATA = AGENTHUB_ROOT / "data"
DB_PATH = DEFAULT_DATA / "project-index-v6.sqlite3"

SOURCE_EXT = {".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx", ".py", ".ps1", ".psm1", ".psd1", ".bat", ".cmd", ".sh", ".asm", ".s", ".inc", ".rc"}
CONFIG_EXT = {".cmake", ".sln", ".vcxproj", ".props", ".targets", ".toml", ".ini", ".cfg", ".conf", ".xml", ".json", ".yml", ".yaml"}
KNOWLEDGE_EXT = {".md", ".rst", ".txt", ".log", ".csv", ".jsonl"}
SKIP_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "__pycache__", "node_modules",
    "third_party", "3rdparty", "vendor", "dependencies", "build", "dist", "out", "target",
    "cmake-build-debug", "cmake-build-release", "debug", "release", "bin", "obj",
    "cache", ".cache", ".idea", ".vs", "_deps", "pcsx2_autogen", "diagnostics",
}
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_LIVE_READ_BYTES = 2 * 1024 * 1024
CHUNK_LINES = 90
OVERLAP_LINES = 15
MAX_CHUNKS = 150000
SENSITIVE_NAMES = {".env", ".env.local", "secrets.json", "credentials.json", "id_rsa", "id_ed25519", "known_hosts"}
SENSITIVE_SUFFIXES = {".pem", ".pfx", ".p12", ".key", ".kdbx", ".keystore", ".env", ".secret"}
SENSITIVE_DIRS = {".git", ".ssh", ".aws", ".azure", ".kube"}


def _resolved(value: str | Path) -> Path:
    return Path(value).expanduser().resolve()


def project_root() -> Path:
    """Return the explicitly configured project root (AgentHub by default)."""
    return CONFIGURED_PROJECT_ROOT


def agenthub_root() -> Path:
    return AGENTHUB_ROOT


def task_workdir() -> Path:
    """Return the configured project root; defaults safely to AgentHub itself."""
    return CONFIGURED_PROJECT_ROOT


def allowed_roots() -> list[Path]:
    """AgentHub plus one explicit project root; no arbitrary environment roots."""
    roots = [AGENTHUB_ROOT, CONFIGURED_PROJECT_ROOT]
    unique: list[Path] = []
    for root in roots:
        resolved = root.resolve()
        if resolved not in unique:
            unique.append(resolved)
    return unique


def _inside(path: Path, roots: list[Path]) -> bool:
    return any(path == root or root in path.parents for root in roots)


def _sensitive(path: Path, roots: list[Path]) -> bool:
    try:
        relative_parts = path.relative_to(next(root for root in roots if path == root or root in path.parents)).parts
    except (StopIteration, ValueError):
        relative_parts = path.parts
    return (path.name.lower() in SENSITIVE_NAMES or path.name.lower().startswith(".env")
            or path.suffix.lower() in SENSITIVE_SUFFIXES
            or any(part.lower() in SENSITIVE_DIRS for part in relative_parts[:-1]))


def resolve_task_path(raw_path: str, base_dir: str | Path | None = None) -> tuple[Path, list[Path]]:
    raw = raw_path.strip().strip('"').strip("'")
    if not raw or "\x00" in raw:
        raise ValueError("Leerer oder ungueltiger Pfad.")
    # Accept native paths on the host OS while still understanding Windows-style
    # relative paths in cross-platform tests and development environments.
    if os.name == "nt":
        raw = raw.replace("/", "\\")
        prefix = ".\\"
    else:
        raw = raw.replace("\\", "/")
        prefix = "./"
    while raw.startswith(prefix):
        raw = raw[len(prefix):]
    candidate = Path(raw) if Path(raw).is_absolute() else _resolved(base_dir or task_workdir()) / raw
    return candidate.resolve(), allowed_roots()


def connect() -> sqlite3.Connection:
    DEFAULT_DATA.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB_PATH)
    db.execute("""CREATE TABLE IF NOT EXISTS chunks (
        id INTEGER PRIMARY KEY, path TEXT NOT NULL, scope TEXT NOT NULL,
        start_line INTEGER NOT NULL, end_line INTEGER NOT NULL,
        content TEXT NOT NULL, sha256 TEXT NOT NULL)""")
    db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(path)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_chunks_scope ON chunks(scope)")
    db.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
        USING fts5(path, scope, content, content='chunks', content_rowid='id')""")
    db.executescript("""
    CREATE TRIGGER IF NOT EXISTS chunks_ai AFTER INSERT ON chunks BEGIN
      INSERT INTO chunks_fts(rowid,path,scope,content) VALUES(new.id,new.path,new.scope,new.content);
    END;
    CREATE TRIGGER IF NOT EXISTS chunks_ad AFTER DELETE ON chunks BEGIN
      INSERT INTO chunks_fts(chunks_fts,rowid,path,scope,content) VALUES('delete',old.id,old.path,old.scope,old.content);
    END;
    CREATE TRIGGER IF NOT EXISTS chunks_au AFTER UPDATE ON chunks BEGIN
      INSERT INTO chunks_fts(chunks_fts,rowid,path,scope,content) VALUES('delete',old.id,old.path,old.scope,old.content);
      INSERT INTO chunks_fts(rowid,path,scope,content) VALUES(new.id,new.path,new.scope,new.content);
    END;
    """)
    db.commit()
    return db


def classify(path: Path) -> str | None:
    name, suffix = path.name.lower(), path.suffix.lower()
    if name.endswith(".meta.txt") or name in {"parsecache.txt", "cmakeconfigurelog.yaml"}:
        return None
    if suffix in SOURCE_EXT:
        return "source"
    if suffix in CONFIG_EXT or name in {"cmakelists.txt", ".gitignore", ".gitattributes"}:
        return "config"
    if suffix in KNOWLEDGE_EXT:
        return "knowledge"
    return None


def priority(path: Path, scope: str) -> tuple[int, str]:
    name = path.name.lower()
    if name.startswith(("readme", "architecture", "design", "status", "phase", "report", "manifest", "validation")):
        rank = 0
    elif scope == "source":
        rank = 1
    elif scope == "config":
        rank = 2
    else:
        rank = 3
    return rank, str(path).lower()


def iter_files(root: Path) -> list[tuple[Path, str]]:
    found: list[tuple[Path, str]] = []
    for current, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d.lower() not in SKIP_DIRS and not d.lower().startswith(("cmake-build-", "build-")))
        base = Path(current)
        for filename in files:
            path = base / filename
            if path.is_symlink():
                continue
            scope = classify(path)
            if scope:
                try:
                    if path.stat().st_size <= MAX_FILE_BYTES:
                        found.append((path, scope))
                except OSError:
                    pass
    found.sort(key=lambda item: priority(item[0].relative_to(root), item[1]))
    return found


def chunks_for(path: Path, root: Path, scope: str) -> Iterator[tuple]:
    try:
        raw = path.read_bytes()
        if b"\x00" in raw:
            return
        content = raw.decode("utf-8-sig", errors="replace")
    except OSError:
        return
    lines = content.splitlines()
    if not lines:
        return
    rel = path.relative_to(root).as_posix()
    digest = hashlib.sha256(raw).hexdigest()
    step = max(1, CHUNK_LINES - OVERLAP_LINES)
    for start in range(0, len(lines), step):
        part = lines[start:start + CHUNK_LINES]
        if not part:
            break
        yield (rel, scope, start + 1, start + len(part), "\n".join(part), digest)
        if start + CHUNK_LINES >= len(lines):
            break


def build_index(root: Path) -> dict:
    root = root.resolve()
    if not _inside(root, allowed_roots()):
        raise PermissionError("Indexierung ausserhalb der explizit freigegebenen Projektroots ist gesperrt.")
    if not root.is_dir():
        raise FileNotFoundError(f"Projektordner nicht gefunden: {root}")
    files = iter_files(root)
    db = connect()
    db.execute("DELETE FROM chunks")
    written, indexed_files, batch = 0, 0, []
    counts = {"source": 0, "config": 0, "knowledge": 0}
    for path, scope in files:
        had_chunk = False
        for row in chunks_for(path, root, scope):
            batch.append(row)
            had_chunk = True
            if len(batch) >= 500:
                db.executemany("INSERT INTO chunks(path,scope,start_line,end_line,content,sha256) VALUES(?,?,?,?,?,?)", batch)
                written += len(batch)
                batch.clear()
            if written + len(batch) >= MAX_CHUNKS:
                break
        if had_chunk:
            indexed_files += 1
            counts[scope] += 1
        if written + len(batch) >= MAX_CHUNKS:
            break
    if batch:
        db.executemany("INSERT INTO chunks(path,scope,start_line,end_line,content,sha256) VALUES(?,?,?,?,?,?)", batch)
        written += len(batch)
    db.commit()
    db.execute("INSERT INTO chunks_fts(chunks_fts) VALUES('optimize')")
    db.commit()
    db.close()
    return {"root": str(root), "database": str(DB_PATH), "candidate_files": len(files), "indexed_files": indexed_files,
            "chunks_indexed": written, "max_chunks_reached": written >= MAX_CHUNKS,
            "source_files": counts["source"], "config_files": counts["config"], "knowledge_files": counts["knowledge"],
            "excluded_directories": sorted(SKIP_DIRS), "max_file_bytes": MAX_FILE_BYTES}


def make_fts_query(query: str) -> str:
    terms = list(dict.fromkeys(re.findall(r"[A-Za-z0-9_]{2,}", query.lower())))[:32]
    stop = {"der", "die", "das", "und", "oder", "ist", "sind", "wie", "was", "wo", "ich", "du", "bitte", "analysiere", "analysieren", "zeige", "mir", "finde", "suche", "datei", "inhalt", "projekt", "kannst", "mal", "the", "and", "for", "with", "from", "this", "that"}
    terms = [t for t in terms if t not in stop]
    return " OR ".join(f'"{term}"' for term in terms)


def search_project(query: str, limit: int = 12, scope: str = "all") -> list[dict]:
    if not DB_PATH.exists():
        return []
    fts = make_fts_query(query)
    if not fts:
        return []
    db = sqlite3.connect(DB_PATH)
    try:
        sql = """SELECT c.path,c.scope,c.start_line,c.end_line,c.content,bm25(chunks_fts,5.0,2.0,1.0) score
                 FROM chunks_fts JOIN chunks c ON c.id=chunks_fts.rowid WHERE chunks_fts MATCH ?"""
        args: list = [fts]
        if scope != "all":
            sql += " AND c.scope=?"
            args.append(scope)
        sql += " ORDER BY score LIMIT ?"
        args.append(max(1, min(limit * 5, 100)))
        rows = db.execute(sql, args).fetchall()
    except sqlite3.OperationalError:
        rows = []
    finally:
        db.close()
    terms = [t for t in re.findall(r"[A-Za-z0-9_]{2,}", query.lower()) if len(t) > 2]
    scored = []
    for r in rows:
        path_l = r[0].lower()
        base = Path(path_l).name
        score = float(r[5])
        score -= sum(0.85 for t in terms if t in base)
        score -= sum(0.30 for t in terms if t in path_l)
        scored.append((score, r))
    scored.sort(key=lambda x: (x[0], x[1][0], x[1][2]))
    # Diversify by file: one strongest chunk per path prevents a long README/source file
    # from consuming every retrieval slot and hiding other relevant project files.
    seen_paths, out = set(), []
    for score, r in scored:
        if r[0] in seen_paths:
            continue
        seen_paths.add(r[0])
        out.append({"path": r[0], "scope": r[1], "start_line": r[2], "end_line": r[3], "content": r[4], "score": score})
        if len(out) >= limit:
            break
    return out


def find_indexed_files(name_or_path: str, limit: int = 30) -> list[str]:
    if not DB_PATH.exists():
        return []
    needle = name_or_path.replace("\\", "/").strip(" /").lower()
    db = sqlite3.connect(DB_PATH)
    try:
        rows = db.execute("SELECT DISTINCT path FROM chunks ORDER BY path").fetchall()
    finally:
        db.close()
    matches = [r[0] for r in rows if needle in r[0].lower() or Path(r[0]).name.lower() == needle]
    return matches[:max(1, min(limit, 100))]


def _not_found_candidates(path: Path, roots: list[Path], limit: int = 30) -> list[str]:
    name = path.name.lower()
    found: list[str] = []
    for root in roots:
        try:
            for item in root.rglob(name):
                if (item.is_file() and not _sensitive(item.resolve(), roots)
                        and not any(part.lower() in SKIP_DIRS for part in item.relative_to(root).parts)):
                    found.append(str(item.resolve()))
                    if len(found) >= limit:
                        return found
        except OSError:
            continue
    return sorted(dict.fromkeys(found), key=str.lower)


def read_project_file(relative_path: str, max_bytes: int = MAX_LIVE_READ_BYTES,
                     base_dir: str | Path | None = None) -> dict:
    """Read a text file relative to the task workdir or an explicit absolute path."""
    try:
        resolved, roots = resolve_task_path(relative_path, base_dir)
    except ValueError as exc:
        return {"ok": False, "status": "read_error", "checked_path": "", "message": str(exc)}
    checked = str(resolved)
    if not roots:
        return {"ok": False, "status": "access_denied", "checked_path": checked, "message": "Kein freigegebener Suchbereich ist erreichbar."}
    if not _inside(resolved, roots):
        return {"ok": False, "status": "access_denied", "checked_path": checked, "message": "Der Pfad liegt ausserhalb der freigegebenen Arbeitsordner."}
    if _sensitive(resolved, roots):
        return {"ok": False, "status": "access_denied", "checked_path": checked, "message": "Diese Datei ist aus Sicherheitsgruenden blockiert."}
    if not resolved.exists():
        candidates = _not_found_candidates(resolved, roots)
        indexed = find_indexed_files(relative_path, limit=8)
        status = "not_found" if not indexed else "not_indexed"
        return {"ok": False, "status": status, "checked_path": checked,
                "candidates": candidates, "indexed_candidates": indexed,
                "message": f"Gepruefter absoluter Pfad: {checked}. Datei nicht gefunden." +
                           (" Es gibt Index-Treffer, aber keinen Live-Treffer." if indexed else "")}
    if not resolved.is_file():
        return {"ok": False, "status": "read_error", "checked_path": checked, "message": "Der angegebene Pfad ist keine Datei."}
    try:
        size = resolved.stat().st_size
        if size > max_bytes:
            return {"ok": False, "status": "read_error", "checked_path": checked, "message": f"Datei ist {size} Bytes gross; Limit: {max_bytes} Bytes."}
        raw = resolved.read_bytes()
        if b"\x00" in raw:
            return {"ok": False, "status": "read_error", "checked_path": checked, "message": "Binaerdatei; Textlesen ist nicht moeglich."}
        content = raw.decode("utf-8-sig", errors="replace")
        lines = content.splitlines()
        return {"ok": True, "status": "read", "path": str(resolved), "checked_path": checked,
                "bytes": size, "line_count": len(lines), "content": content}
    except PermissionError as exc:
        return {"ok": False, "status": "access_denied", "checked_path": checked, "message": f"Zugriff verweigert: {exc}"}
    except OSError as exc:
        return {"ok": False, "status": "read_error", "checked_path": checked, "message": f"Lesefehler: {exc}"}


def list_directory(path: str = ".", base_dir: str | Path | None = None) -> dict:
    try:
        resolved, roots = resolve_task_path(path, base_dir)
    except ValueError as exc:
        return {"ok": False, "status": "read_error", "message": str(exc)}
    if not _inside(resolved, roots) or _sensitive(resolved, roots):
        return {"ok": False, "status": "access_denied", "checked_path": str(resolved), "message": "Verzeichnis liegt ausserhalb des freigegebenen Bereichs oder ist geschuetzt."}
    try:
        if not resolved.is_dir():
            return {"ok": False, "status": "not_found", "checked_path": str(resolved), "message": "Verzeichnis nicht gefunden."}
        entries = [{"name": x.name, "path": str(x.resolve()), "kind": "dir" if x.is_dir() else "file"}
                   for x in sorted(resolved.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
                   if not _sensitive(x.resolve(), roots)]
        return {"ok": True, "status": "listed", "path": str(resolved), "entries": entries}
    except PermissionError as exc:
        return {"ok": False, "status": "access_denied", "checked_path": str(resolved), "message": str(exc)}
    except OSError as exc:
        return {"ok": False, "status": "read_error", "checked_path": str(resolved), "message": str(exc)}


def find_text(path: str, needle: str, base_dir: str | Path | None = None, max_matches: int = 100) -> dict:
    result = read_project_file(path, base_dir=base_dir)
    if not result["ok"]:
        return result
    matches = [{"line": i, "text": line} for i, line in enumerate(result["content"].splitlines(), 1)
               if needle.lower() in line.lower()][:max_matches]
    return {"ok": True, "status": "searched", "path": result["path"], "needle": needle, "matches": matches}


def file_metadata(path: str, base_dir: str | Path | None = None) -> dict:
    try:
        resolved, roots = resolve_task_path(path, base_dir)
    except ValueError as exc:
        return {"ok": False, "status": "read_error", "message": str(exc)}
    if not _inside(resolved, roots) or _sensitive(resolved, roots):
        return {"ok": False, "status": "access_denied", "checked_path": str(resolved), "message": "Pfad ist nicht freigegeben."}
    try:
        st = resolved.stat()
        return {"ok": True, "status": "metadata", "path": str(resolved), "is_dir": resolved.is_dir(), "bytes": st.st_size,
                "modified": st.st_mtime, "created": st.st_ctime}
    except FileNotFoundError:
        return {"ok": False, "status": "not_found", "checked_path": str(resolved), "message": "Pfad nicht gefunden."}
    except PermissionError as exc:
        return {"ok": False, "status": "access_denied", "checked_path": str(resolved), "message": str(exc)}
    except OSError as exc:
        return {"ok": False, "status": "read_error", "checked_path": str(resolved), "message": str(exc)}


_TASK_RE = re.compile(r"^\s*(Get-Content|gc|type|cat|Get-ChildItem|gci|dir|ls|Get-Item|Select-String|sls)\b(.*)$", re.I | re.S)


def execute_structured_file_task(task: str, base_dir: str | Path | None = None) -> dict | None:
    """Interpret a small allowlisted read-only command grammar; never invokes a shell."""
    match = _TASK_RE.match(task.strip())
    if not match:
        return None
    command, rest = match.group(1).lower(), match.group(2).strip()
    path_match = re.search(r"(?:-LiteralPath|-Path)\s+('([^']+)'|\"([^\"]+)\"|(\S+))", rest, re.I)
    quoted = path_match.groups()[1:] if path_match else ()
    path = next((x for x in quoted if x), "")
    if not path:
        bare = re.match(r"(?:-Raw\s+)?(?:'([^']+)'|\"([^\"]+)\"|(\S+))", rest, re.I)
        path = next((x for x in (bare.groups() if bare else ()) if x), ".")
    if command in {"get-childitem", "gci", "dir", "ls"}:
        return {"operation": "list", "result": list_directory(path, base_dir)}
    if command in {"get-item"}:
        return {"operation": "metadata", "result": file_metadata(path, base_dir)}
    if command in {"select-string", "sls"}:
        needle_match = re.search(r"(?:-Pattern)\s+('([^']+)'|\"([^\"]+)\"|(\S+))", rest, re.I)
        needle = next((x for x in (needle_match.groups()[1:] if needle_match else ()) if x), "")
        if not needle:
            return {"operation": "search", "result": {"ok": False, "status": "read_error", "message": "Select-String benoetigt -Pattern."}}
        return {"operation": "search", "result": find_text(path, needle, base_dir)}
    read = read_project_file(path, base_dir=base_dir)
    if read.get("ok") and re.search(r"-TotalCount\s+(\d+)", rest, re.I):
        count = int(re.search(r"-TotalCount\s+(\d+)", rest, re.I).group(1))
        read["content"] = "\n".join(read["content"].splitlines()[:count])
    return {"operation": "read", "result": read}


def main() -> int:
    parser = argparse.ArgumentParser(description="PS2RC read-only project index v6")
    sub = parser.add_subparsers(dest="command", required=True)
    p_index = sub.add_parser("index"); p_index.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    p_search = sub.add_parser("search"); p_search.add_argument("query"); p_search.add_argument("--limit", type=int, default=12); p_search.add_argument("--scope", choices=["all", "source", "config", "knowledge"], default="all")
    p_read = sub.add_parser("read"); p_read.add_argument("path")
    p_find = sub.add_parser("find"); p_find.add_argument("name")
    args = parser.parse_args()
    if args.command == "index":
        result = build_index(args.root)
        print("INDEX BUILD V6")
        for key, value in result.items(): print(f"{key}: {value}")
        return 0
    if args.command == "read":
        result = read_project_file(args.path)
        if not result["ok"]: print(result["message"]); return 2
        print(f"LIVE FILE: {result['path']} ({result['line_count']} lines)\n{result['content']}")
        return 0
    if args.command == "find":
        for path in find_indexed_files(args.name): print(path)
        return 0
    hits = search_project(args.query, args.limit, args.scope)
    if not hits: print("Keine passenden indexierten Textstellen gefunden."); return 2
    for i, hit in enumerate(hits, 1):
        print(f"\n[{i}] [{hit['scope']}] {hit['path']}:{hit['start_line']}-{hit['end_line']}\n{hit['content']}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
